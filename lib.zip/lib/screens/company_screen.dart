// ignore_for_file: deprecated_member_use
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/brand_model.dart';
import '../models/category_model.dart';
import '../models/company_model.dart';
import '../models/product_model.dart';
import '../services/api_config.dart';
import '../services/brand_service.dart';
import '../services/category_service.dart';
import '../services/company_service.dart';
import '../services/product_service.dart';
import '../theme/app_theme.dart';
import '../widgets/delete_confirm_dialog.dart';
import '../widgets/feedback_toast.dart';
import '../widgets/file_upload_box.dart';
import '../widgets/status_badge_chip.dart';
import 'package:share_plus/share_plus.dart';
import '../services/media_picker_helper.dart';
import '../widgets/company_share_dialog.dart';
import '../widgets/company_search_bar.dart';
import '../widgets/business_card_ocr_banner.dart';
import 'package:http/http.dart' as http;
import '../widgets/business_card_ocr_dialog.dart';
import '../widgets/fast_autofill_banner.dart';

class CompanyScreen extends StatefulWidget {
  const CompanyScreen({super.key});

  @override
  State<CompanyScreen> createState() => CompanyScreenState();
}

class CompanyScreenState extends State<CompanyScreen> {
  final CompanyService _companyService = CompanyService();
  final BrandService _brandService = BrandService();
  final ProductService _productService = ProductService();
  final CategoryService _categoryService = CategoryService();

  bool _isOcrPicking = false;

  Future<void> _handleOcrCardUpload([
    Uint8List? existingBytes,
    String? existingName,
    int? existingSize,
    String? existingPath,
  ]) async {
    try {
      Uint8List? bytes = existingBytes;
      String? fileName = existingName;
      int? fileSize = existingSize;
      String? filePath = existingPath;

      if (bytes == null) {
        setState(() => _isOcrPicking = true);
        final picked = await MediaPickerHelper.showMediaPickerSheet(
          context,
          title: 'Upload Visiting Card (Image or PDF)',
          subtitle:
              'Capture with camera, choose from gallery, or select PDF to auto-fill details',
          allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'pdf'],
          allowDocuments: true,
        );

        if (picked != null) {
          bytes = picked.bytes;
          fileSize = picked.size;
          fileName = picked.name;
          filePath = picked.path;
        }
      }

      if (bytes == null || fileName == null || !mounted) return;

      final dialogResult = await BusinessCardOcrDialog.show(
        context,
        imageBytes: bytes,
        fileName: fileName,
        fileSize: fileSize ?? bytes.length,
        filePath: filePath,
        onUnrecognized: (title, message) {
          if (mounted) {
            setState(() {
              _feedback = FeedbackData(
                type: 'error',
                title: title,
                message: message,
              );
            });
          }
        },
      );

      if (dialogResult != null && mounted) {
        _applyOcrResult(dialogResult);
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _feedback = FeedbackData(
            type: 'error',
            title: 'OCR Scanning Failed',
            message: e.toString().replaceAll('Exception:', '').trim(),
          );
        });
      }
    } finally {
      if (mounted) {
        setState(() => _isOcrPicking = false);
      }
    }
  }

  void _applyOcrResult(BusinessCardOcrDialogResult dialogResult) {
    final res = dialogResult.result;
    setState(() {
      if (res.companyName != null && res.companyName!.trim().isNotEmpty) {
        _nameController.text = res.companyName!.trim();
      }
      if (res.contactName != null && res.contactName!.trim().isNotEmpty) {
        _contactNameController.text = res.contactName!.trim();
      }
      if (res.contactDesignation != null &&
          res.contactDesignation!.trim().isNotEmpty) {
        _contactDesignationController.text = res.contactDesignation!.trim();
      }
      if (res.email != null && res.email!.trim().isNotEmpty) {
        _emailController.text = res.email!.trim();
      }
      if (res.contactEmail != null && res.contactEmail!.trim().isNotEmpty) {
        _contactEmailController.text = res.contactEmail!.trim();
      }
      if (res.contactMobileNumber != null &&
          res.contactMobileNumber!.trim().isNotEmpty) {
        _contactMobileController.text = res.contactMobileNumber!.trim();
      }
      if (res.landline != null && res.landline!.trim().isNotEmpty) {
        _landlineController.text = res.landline!.trim();
      }
      if (res.website != null && res.website!.trim().isNotEmpty) {
        _websiteController.text = res.website!.trim();
      }
      if (res.address != null && res.address!.trim().isNotEmpty) {
        _addressController.text = res.address!.trim();
      }
      if (res.city != null && res.city!.trim().isNotEmpty) {
        _cityController.text = res.city!.trim();
      }
      if (res.country != null && res.country!.trim().isNotEmpty) {
        _countryController.text = _normalizeCountry(res.country);
      }

      if (dialogResult.attachCardToForm) {
        _selectedFileBytes = dialogResult.imageBytes;
        _selectedFileName = dialogResult.fileName;
        _selectedFileSize = dialogResult.fileSize;
        _selectedFilePath = dialogResult.filePath;
      }

      _feedback = FeedbackData(
        type: 'success',
        title: 'Business Card Details Applied! 🎉',
        message:
            'Extracted company "${res.companyName ?? 'Detected'}", contact "${res.contactName ?? 'Detected'}" and related details have auto-filled into the form.',
      );
    });
  }

  // Handle device back press
  bool handleBackPress() {
    if (_selectedCompany != null) {
      setState(() => _selectedCompany = null);
      return true;
    }
    if (_showLivePreview) {
      setState(() => _showLivePreview = false);
      return true;
    }
    if (_editingCompanyId != null) {
      _resetForm();
      return true;
    }
    if (_activeTab == 'directory') {
      setState(() => _activeTab = 'register');
      return true;
    }
    return false;
  }

  // Navigation & Loading State
  String _activeTab = 'register'; // 'register' or 'directory'
  bool _isLoadingList = false;
  bool _isLoadingBrands = false;
  bool _isLoadingProducts = false;
  bool _isLoadingCategories = false;
  bool _isSubmitting = false;
  bool _isExportingExcel = false;
  bool _isExportingPdf = false;
  FeedbackData? _feedback;

  // Edit Mode
  int? _editingCompanyId;

  // Form Field Controllers
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final FocusNode _companyNameFocusNode = FocusNode();
  bool _isCompanyNameFocused = false;
  final _emailController = TextEditingController();
  final _landlineController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();
  final _countryController = TextEditingController(text: 'USA - United States');

  static const List<String> _countryList = [
    'USA - United States',
    'CAN - Canada',
    'GBR - United Kingdom',
    'AUS - Australia',
    'IND - India',
    'DEU - Germany',
    'FRA - France',
    'ARE - United Arab Emirates',
    'SAU - Saudi Arabia',
    'QAT - Qatar',
    'KWT - Kuwait',
    'BHR - Bahrain',
    'OMN - Oman',
    'SGP - Singapore',
    'MYS - Malaysia',
    'JPN - Japan',
    'CHN - China',
    'KOR - South Korea',
    'NLD - Netherlands',
    'CHE - Switzerland',
    'ITA - Italy',
    'ESP - Spain',
    'SWE - Sweden',
    'NOR - Norway',
    'DNK - Denmark',
    'FIN - Finland',
    'IRL - Ireland',
    'BEL - Belgium',
    'AUT - Austria',
    'POL - Poland',
    'TUR - Turkey',
    'BRA - Brazil',
    'MEX - Mexico',
    'ZAF - South Africa',
    'NZL - New Zealand',
    'EGY - Egypt',
    'JOR - Jordan',
    'LBN - Lebanon',
    'IDN - Indonesia',
    'THA - Thailand',
    'VNM - Vietnam',
    'PHL - Philippines',
    'PAK - Pakistan',
    'BGD - Bangladesh',
    'NGA - Nigeria',
    'KEN - Kenya',
    'ARG - Argentina',
    'CHL - Chile',
    'COL - Colombia',
  ];

  String _normalizeCountry(String? raw) {
    if (raw == null || raw.trim().isEmpty) return 'USA - United States';
    final trimmed = raw.trim();
    for (final opt in _countryList) {
      if (opt.toLowerCase() == trimmed.toLowerCase()) return opt;
      final parts = opt.split(' - ');
      if (parts.length == 2) {
        if (parts[0].toLowerCase() == trimmed.toLowerCase() ||
            parts[1].toLowerCase() == trimmed.toLowerCase()) {
          return opt;
        }
      }
    }
    final lower = trimmed.toLowerCase();
    if (lower == 'us' || lower == 'usa' || lower == 'united states of america') {
      return 'USA - United States';
    }
    if (lower == 'uk' || lower == 'great britain' || lower == 'britain') {
      return 'GBR - United Kingdom';
    }
    if (lower == 'uae') {
      return 'ARE - United Arab Emirates';
    }
    return trimmed;
  }
  final _websiteController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _contactNameController = TextEditingController();
  final _contactDesignationController = TextEditingController();
  final _contactEmailController = TextEditingController();
  final _contactMobileController = TextEditingController();
  String _status = 'ACTIVE';

  // Section 05: Brands Dealt With State
  List<BrandResponse> _availableBrands = [];
  List<int> _selectedBrandIds = [];
  final Set<int> _manuallySelectedBrandIds = {};
  String _brandSearchQuery = '';

  // Section 06: Products Catalog State
  List<ProductResponse> _availableProducts = [];
  List<CategoryResponse> _availableCategories = [];
  List<int> _selectedProductIds = [];
  String _productSearchQuery = '';
  String _activeProductBrandFilter = 'all';
  String _activeProductCategoryFilter = 'all';
  String _activeProductSubCategoryFilter = 'all';

  // Section 03 & 06: Website Product Scraping State (Matching Angular)
  bool _isScrapingWebsite = false;
  bool _isScrapedDrawerOpen = false;
  List<ScrapedProduct> _scrapedProducts = [];
  String _scrapedWebsiteUrl = '';
  String _scrapedStrategyUsed = '';
  final Set<int> _selectedScrapedIndices = {};
  final GlobalKey _scrapedDrawerKey = GlobalKey();

  // Section 07: File Upload State
  Uint8List? _selectedFileBytes;
  String? _selectedFileName;
  int? _selectedFileSize;
  String? _selectedFilePath;
  String? _existingFileUrl;

  // Directory State
  List<CompanyResponse> _companies = [];
  String _searchQuery = '';
  final TextEditingController _searchController = TextEditingController();

  // Modal State
  CompanyResponse? _selectedCompany;

  // Live preview toggle for mobile
  bool _showLivePreview = false;

  final ApiConfig _apiConfig = ApiConfig();

  @override
  void initState() {
    super.initState();
    _apiConfig.addListener(_onConfigChanged);
    _companyNameFocusNode.addListener(() {
      if (mounted) {
        setState(() {
          _isCompanyNameFocused = _companyNameFocusNode.hasFocus;
        });
      }
    });
    _fetchAllData();
  }

  void _onConfigChanged() {
    if (mounted) {
      _fetchAllData();
    }
  }

  void _fetchAllData() {
    _fetchCompanies();
    _fetchBrands();
    _fetchProducts();
    _fetchCategories();
  }

  @override
  void dispose() {
    _apiConfig.removeListener(_onConfigChanged);
    _companyNameFocusNode.dispose();
    _nameController.dispose();
    _emailController.dispose();
    _landlineController.dispose();
    _addressController.dispose();
    _cityController.dispose();
    _countryController.dispose();
    _websiteController.dispose();
    _descriptionController.dispose();
    _contactNameController.dispose();
    _contactDesignationController.dispose();
    _contactEmailController.dispose();
    _contactMobileController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  // --- Hierarchy Computations ---
  List<CategoryResponse> get _parentCategories {
    return _availableCategories.where((c) => c.parentId == null).toList();
  }

  List<CategoryResponse> get _subCategories {
    final parents = _parentCategories;
    return _availableCategories.where((c) => c.parentId != null).map((sub) {
      final parent = parents.cast<CategoryResponse?>().firstWhere(
        (p) => p?.id == sub.parentId,
        orElse: () => null,
      );
      return sub.copyWith(parentName: parent?.name ?? 'None');
    }).toList();
  }

  List<BrandResponse> get _filteredAvailableBrands {
    final query = _brandSearchQuery.toLowerCase().trim();
    if (query.isEmpty) return _availableBrands;
    return _availableBrands
        .where((b) => b.brandName.toLowerCase().contains(query))
        .toList();
  }

  List<BrandResponse> get _selectedBrandsList {
    final ids = _selectedBrandIds.toSet();
    return _availableBrands.where((b) => ids.contains(b.id)).toList();
  }

  // Brands with Product Counts
  List<Map<String, dynamic>> get _brandsWithProducts {
    return _availableBrands.map((b) {
      final count = _availableProducts.where((p) => p.brandId == b.id).length;
      return {'brand': b, 'count': count};
    }).toList();
  }

  // Categories available for current brand filter
  List<CategoryResponse> get _availableCategoriesForBrand {
    var prods = _availableProducts;
    if (_activeProductBrandFilter != 'all') {
      final bId = int.tryParse(_activeProductBrandFilter);
      if (bId != null) prods = prods.where((p) => p.brandId == bId).toList();
    }
    final catIds = prods.map((p) => p.categoryId).toSet();
    return _parentCategories.where((c) => catIds.contains(c.id)).toList();
  }

  // Subcategories available under selected brand & category
  List<CategoryResponse> get _availableSubCategoriesForSelection {
    var prods = _availableProducts;
    if (_activeProductBrandFilter != 'all') {
      final bId = int.tryParse(_activeProductBrandFilter);
      if (bId != null) prods = prods.where((p) => p.brandId == bId).toList();
    }
    if (_activeProductCategoryFilter != 'all') {
      final cId = int.tryParse(_activeProductCategoryFilter);
      if (cId != null) prods = prods.where((p) => p.categoryId == cId).toList();
    }
    final subCatIds = prods
        .where((p) => p.subCategoryId != null)
        .map((p) => p.subCategoryId!)
        .toSet();
    return _subCategories.where((s) => subCatIds.contains(s.id)).toList();
  }

  // Filtered Products for Selection Grid
  List<ProductResponse> get _filteredAvailableProducts {
    final query = _productSearchQuery.toLowerCase().trim();
    final bFilter = _activeProductBrandFilter;
    final cFilter = _activeProductCategoryFilter;
    final sFilter = _activeProductSubCategoryFilter;

    return _availableProducts.where((p) {
      if (bFilter != 'all' && p.brandId.toString() != bFilter) return false;
      if (cFilter != 'all' && p.categoryId.toString() != cFilter) return false;
      if (sFilter != 'all' && p.subCategoryId?.toString() != sFilter)
        return false;

      if (query.isNotEmpty) {
        final matches =
            p.name.toLowerCase().contains(query) ||
            (p.brandName ?? '').toLowerCase().contains(query) ||
            (p.categoryName ?? '').toLowerCase().contains(query) ||
            (p.subCategoryName ?? '').toLowerCase().contains(query) ||
            p.id.toString().contains(query);
        if (!matches) return false;
      }
      return true;
    }).toList();
  }

  List<ProductResponse> get _selectedProductsList {
    final ids = _selectedProductIds.toSet();
    return _availableProducts.where((p) => ids.contains(p.id)).toList();
  }

  List<CompanyResponse> get _filteredCompanies {
    final query = _searchQuery.toLowerCase().trim();
    if (query.isEmpty) return _companies;
    return _companies.where((c) {
      final matchesName = c.companyName.toLowerCase().contains(query);
      final matchesContact = (c.contactName ?? '').toLowerCase().contains(
        query,
      );
      final matchesContactEmail = (c.contactEmail ?? '').toLowerCase().contains(
        query,
      );
      final matchesEmail = c.email.toLowerCase().contains(query);
      final matchesCity = (c.city ?? '').toLowerCase().contains(query);
      final matchesCountry = (c.country ?? '').toLowerCase().contains(query);
      final matchesBrands = c.brands.any(
        (b) => b.brandName.toLowerCase().contains(query),
      );
      final matchesProducts = c.products.any(
        (p) => p.name.toLowerCase().contains(query),
      );
      return matchesName ||
          matchesContact ||
          matchesContactEmail ||
          matchesEmail ||
          matchesCity ||
          matchesCountry ||
          matchesBrands ||
          matchesProducts;
    }).toList();
  }

  // --- Fetching Data ---
  Future<void> _fetchCompanies() async {
    setState(() => _isLoadingList = true);
    try {
      final data = await _companyService.getAllCompanies();
      if (mounted)
        setState(() {
          _companies = data;
          _isLoadingList = false;
        });
    } catch (_) {
      if (mounted) setState(() => _isLoadingList = false);
    }
  }

  Future<void> _fetchBrands() async {
    setState(() => _isLoadingBrands = true);
    try {
      final data = await _brandService.getAllBrands();
      if (mounted)
        setState(() {
          _availableBrands = data;
          _isLoadingBrands = false;
        });
    } catch (_) {
      if (mounted) setState(() => _isLoadingBrands = false);
    }
  }

  Future<void> _fetchProducts() async {
    setState(() => _isLoadingProducts = true);
    try {
      final data = await _productService.getAllProducts();
      if (mounted)
        setState(() {
          _availableProducts = data;
          _isLoadingProducts = false;
        });
    } catch (_) {
      if (mounted) setState(() => _isLoadingProducts = false);
    }
  }

  Future<void> _fetchCategories() async {
    setState(() => _isLoadingCategories = true);
    try {
      final data = await _categoryService.getAllCategories();
      if (mounted)
        setState(() {
          _availableCategories = data;
          _isLoadingCategories = false;
        });
    } catch (_) {
      if (mounted) setState(() => _isLoadingCategories = false);
    }
  }

  // --- Brand Selection Handlers ---
  void _toggleBrand(int brandId) {
    setState(() {
      if (_selectedBrandIds.contains(brandId)) {
        // 1. Unselect brand
        _selectedBrandIds.remove(brandId);
        _manuallySelectedBrandIds.remove(brandId);
        // 2. Cascade: automatically unselect all products belonging to this brand
        final prodsOfBrand = _availableProducts
            .where((p) => p.brandId == brandId)
            .map((p) => p.id)
            .toSet();
        _selectedProductIds.removeWhere((id) => prodsOfBrand.contains(id));
      } else {
        // User explicitly selected this brand
        _selectedBrandIds.add(brandId);
        _manuallySelectedBrandIds.add(brandId);
      }
    });
  }

  void _selectAllBrands() {
    setState(() {
      final allIds = _availableBrands.map((b) => b.id).toList();
      _selectedBrandIds = allIds;
      _manuallySelectedBrandIds.addAll(allIds);
    });
  }

  void _clearSelectedBrands() {
    setState(() {
      _selectedBrandIds.clear();
      _manuallySelectedBrandIds.clear();
      _selectedProductIds.clear();
    });
  }

  // --- Product Selection Handlers ---
  void _toggleProduct(ProductResponse product) {
    setState(() {
      if (_selectedProductIds.contains(product.id)) {
        _removeProductAndCheckBrand(product.id, product.brandId);
      } else {
        _selectedProductIds.add(product.id);
        if (!_selectedBrandIds.contains(product.brandId)) {
          _selectedBrandIds.add(product.brandId);
        }
      }
    });
  }

  void _removeProductAndCheckBrand(int productId, int? brandId) {
    _selectedProductIds.remove(productId);
    final bId =
        brandId ??
        _availableProducts
            .cast<ProductResponse?>()
            .firstWhere((p) => p?.id == productId, orElse: () => null)
            ?.brandId;
    if (bId != null) {
      final hasOtherProds = _availableProducts.any(
        (p) => p.brandId == bId && _selectedProductIds.contains(p.id),
      );
      if (!hasOtherProds && !_manuallySelectedBrandIds.contains(bId)) {
        _selectedBrandIds.remove(bId);
      }
    }
  }

  void _selectAllFilteredProducts() {
    setState(() {
      for (final p in _filteredAvailableProducts) {
        if (!_selectedProductIds.contains(p.id)) _selectedProductIds.add(p.id);
        if (!_selectedBrandIds.contains(p.brandId))
          _selectedBrandIds.add(p.brandId);
      }
    });
  }

  void _deselectFilteredProducts() {
    setState(() {
      final filteredIds = _filteredAvailableProducts.map((p) => p.id).toSet();
      _selectedProductIds.removeWhere((id) => filteredIds.contains(id));

      final remainingProds = _availableProducts.where(
        (p) => _selectedProductIds.contains(p.id),
      );
      final activeBrandIds = remainingProds.map((p) => p.brandId).toSet();

      _selectedBrandIds.removeWhere(
        (bId) =>
            !_manuallySelectedBrandIds.contains(bId) &&
            !activeBrandIds.contains(bId),
      );
    });
  }

  void _clearSelectedProducts() {
    setState(() {
      _selectedProductIds.clear();
      _selectedBrandIds.removeWhere(
        (bId) => !_manuallySelectedBrandIds.contains(bId),
      );
    });
  }

  // --- Website Product Scraping Methods (Matching Angular) ---
  String _cleanDisplayUrl(String raw) {
    if (raw.trim().isEmpty) return 'website';
    try {
      String trimmed = raw.trim();
      if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
        trimmed = 'https://$trimmed';
      }
      final uri = Uri.parse(trimmed);
      String host = uri.host;
      if (host.startsWith('www.')) {
        host = host.substring(4);
      }
      if (host.isNotEmpty) {
        return host;
      }
      return raw.trim();
    } catch (_) {
      return raw.trim();
    }
  }

  String _stripTrackingQuery(String raw) {
    if (raw.trim().isEmpty) return raw;
    try {
      String trimmed = raw.trim();
      if (!trimmed.startsWith('http://') && !trimmed.startsWith('https://')) {
        trimmed = 'https://$trimmed';
      }
      final uri = Uri.parse(trimmed);
      final cleanParams = Map<String, String>.from(uri.queryParameters);
      cleanParams.removeWhere(
        (key, _) =>
            key.toLowerCase().startsWith('utm_') ||
            key.toLowerCase() == 'srsltid' ||
            key.toLowerCase() == 'gclid' ||
            key.toLowerCase() == 'fbclid' ||
            key.toLowerCase() == 'ref',
      );

      final cleanUri = uri.replace(
        queryParameters: cleanParams.isEmpty ? null : cleanParams,
      );
      return cleanUri.toString();
    } catch (_) {
      return raw;
    }
  }

  String _cleanPrimaryStrategy(String raw) {
    if (raw.trim().isEmpty) return 'Storefront Engine';
    final first = raw.split(',').first.trim();
    final cleaned = first.replaceAll(RegExp(r'\s*\([^)]*\)'), '').trim();
    return cleaned.isNotEmpty ? cleaned : 'Storefront Engine';
  }

  Future<void> _triggerWebsiteProductScrape() async {
    final website = _websiteController.text.trim();
    if (website.isEmpty) {
      setState(() {
        _feedback = FeedbackData(
          type: 'error',
          title: 'Website Required',
          message:
              'Please provide a valid official website URL in Section 03 before discovering products.',
        );
      });
      return;
    }

    setState(() {
      _isScrapingWebsite = true;
      _isScrapedDrawerOpen = true;
      _feedback = null;
    });

    try {
      final res = await _companyService.scrapeProductsFromWebsite(website);
      if (!mounted) return;

      // Automatically pre-select any products that matched existing catalog products
      final preselectedIndices = <int>{};
      for (int idx = 0; idx < res.products.length; idx++) {
        final p = res.products[idx];
        if (p.matchedCatalogProductId != null) {
          preselectedIndices.add(idx);
          if (!_selectedProductIds.contains(p.matchedCatalogProductId)) {
            final matchedCatalogProd = _availableProducts
                .cast<ProductResponse?>()
                .firstWhere(
                  (ap) => ap?.id == p.matchedCatalogProductId,
                  orElse: () => null,
                );
            if (matchedCatalogProd != null) {
              _toggleProduct(matchedCatalogProd);
            }
          }
        }
      }

      setState(() {
        _isScrapingWebsite = false;
        _scrapedProducts = res.products;
        final cleanUrl = _stripTrackingQuery(
          res.scannedUrl.isNotEmpty ? res.scannedUrl : website,
        );
        _scrapedWebsiteUrl = cleanUrl;
        _scrapedStrategyUsed = res.strategyUsed.isNotEmpty
            ? res.strategyUsed
            : 'Website Crawler';
        _selectedScrapedIndices.clear();
        _selectedScrapedIndices.addAll(preselectedIndices);

        final domain = _cleanDisplayUrl(website);
        final primaryStrategy = _cleanPrimaryStrategy(_scrapedStrategyUsed);

        if (res.products.isNotEmpty) {
          final count = res.products.length;
          final productWord = count == 1 ? 'product' : 'products';
          _feedback = FeedbackData(
            type: 'success',
            title: 'Products Discovered!',
            message: 'Found $count $productWord from $domain',
            badges: [
              FeedbackBadge(icon: Icons.language, label: domain),
              FeedbackBadge(icon: Icons.bolt, label: primaryStrategy),
              FeedbackBadge(
                icon: Icons.inventory_2_outlined,
                label: '$count Items',
              ),
            ],
            actionPrompt:
                'Select the items you want to link to this company below.',
          );
        } else {
          _feedback = FeedbackData(
            type: 'error',
            title: 'No Products Detected',
            message: res.message.isNotEmpty
                ? res.message
                : 'We could not detect standard eCommerce products on $domain.',
            actionPrompt:
                'You can manually choose products from the catalog below.',
          );
        }
      });

      if (res.products.isNotEmpty) {
        _scrollToScrapedDrawer();
      }
    } catch (err) {
      if (!mounted) return;
      setState(() {
        _isScrapingWebsite = false;
        final errMsg = err.toString().replaceAll('Exception:', '').trim();
        final domain = _cleanDisplayUrl(website);
        _feedback = FeedbackData(
          type: 'error',
          title: 'Website Scan Failed',
          message: errMsg.isNotEmpty
              ? errMsg
              : 'Could not fetch or scan $domain. Please ensure the domain is publicly accessible.',
        );
      });
    }
  }

  void _scrollToScrapedDrawer() {
    // Unfocus soft keyboard so the user has full screen visibility
    FocusManager.instance.primaryFocus?.unfocus();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrapedDrawerKey.currentContext != null) {
        Scrollable.ensureVisible(
          _scrapedDrawerKey.currentContext!,
          duration: const Duration(milliseconds: 500),
          curve: Curves.easeInOut,
          alignment: 0.05,
        );
      }
    });
  }

  void _openScrapedDrawerWithScroll() {
    setState(() {
      _isScrapedDrawerOpen = true;
    });
    _scrollToScrapedDrawer();
  }

  void _closeScrapedDrawer() {
    setState(() {
      _isScrapedDrawerOpen = false;
    });
  }

  void _toggleScrapedProduct(int index) {
    if (index < 0 || index >= _scrapedProducts.length) return;
    final product = _scrapedProducts[index];

    setState(() {
      if (_selectedScrapedIndices.contains(index)) {
        _selectedScrapedIndices.remove(index);
        if (product.matchedCatalogProductId != null) {
          _removeProductAndCheckBrand(product.matchedCatalogProductId!, null);
        }
      } else {
        _selectedScrapedIndices.add(index);
        if (product.matchedCatalogProductId != null) {
          final catalogProd = _availableProducts
              .cast<ProductResponse?>()
              .firstWhere(
                (p) => p?.id == product.matchedCatalogProductId,
                orElse: () => null,
              );
          if (catalogProd != null &&
              !_selectedProductIds.contains(product.matchedCatalogProductId)) {
            _toggleProduct(catalogProd);
          }
        }
      }
    });
  }

  void _selectAllScrapedProducts() {
    setState(() {
      for (int idx = 0; idx < _scrapedProducts.length; idx++) {
        _selectedScrapedIndices.add(idx);
        final p = _scrapedProducts[idx];
        if (p.matchedCatalogProductId != null) {
          final catalogProd = _availableProducts
              .cast<ProductResponse?>()
              .firstWhere(
                (cp) => cp?.id == p.matchedCatalogProductId,
                orElse: () => null,
              );
          if (catalogProd != null &&
              !_selectedProductIds.contains(p.matchedCatalogProductId)) {
            _toggleProduct(catalogProd);
          }
        }
      }
    });
  }

  void _deselectAllScrapedProducts() {
    setState(() {
      for (final idx in _selectedScrapedIndices) {
        if (idx < _scrapedProducts.length) {
          final p = _scrapedProducts[idx];
          if (p.matchedCatalogProductId != null) {
            _removeProductAndCheckBrand(p.matchedCatalogProductId!, null);
          }
        }
      }
      _selectedScrapedIndices.clear();
    });
  }

  // --- Section 01: Fast Autofill & Company Suggestions Logic ---
  List<CompanyResponse> get _companyNameSuggestions {
    final q = _nameController.text.trim().toLowerCase();
    if (q.length < 2) return const [];
    return _companies.where((c) {
      final name = c.companyName.trim().toLowerCase();
      return name.contains(q) && name != q;
    }).take(6).toList();
  }

  CompanyResponse? get _exactMatchedCompany {
    final q = _nameController.text.trim().toLowerCase();
    if (q.isEmpty) return null;
    try {
      return _companies.firstWhere(
        (c) => c.companyName.trim().toLowerCase() == q,
      );
    } catch (_) {
      return null;
    }
  }

  void _selectCompanyNameSuggestion(CompanyResponse company) {
    setState(() {
      _nameController.text = company.companyName;
      _isCompanyNameFocused = false;
      _companyNameFocusNode.unfocus();
    });
  }

  void _autofillFormWithCompany(CompanyResponse company) {
    setState(() {
      _nameController.text = company.companyName.isNotEmpty
          ? '${company.companyName} (Copy)'
          : '';
      _emailController.text = company.email;
      _landlineController.text = company.landline ?? '';
      _addressController.text = company.address ?? '';
      _cityController.text = company.city ?? '';
      _countryController.text = _normalizeCountry(company.country);
      _websiteController.text = company.website ?? '';
      _descriptionController.text = company.description ?? '';
      _status = company.status.isNotEmpty ? company.status : 'ACTIVE';
      _contactNameController.text = company.contactName ?? '';
      _contactDesignationController.text = company.contactDesignation ?? '';
      _contactEmailController.text = company.contactEmail ?? '';
      _contactMobileController.text = company.contactMobileNumber ?? '';

      final bIds = company.brandIds.isNotEmpty
          ? List<int>.from(company.brandIds)
          : company.brands.map((b) => b.id).toList();
      _selectedBrandIds = bIds;
      _manuallySelectedBrandIds.clear();
      _manuallySelectedBrandIds.addAll(bIds);

      final pIds = company.productIds.isNotEmpty
          ? List<int>.from(company.productIds)
          : company.products.map((p) => p.id).toList();
      _selectedProductIds = pIds;

      _selectedFileBytes = null;
      _selectedFileName = null;
      _selectedFileSize = null;
      _selectedFilePath = null;
      _existingFileUrl = null;

      _scrapedProducts.clear();
      _selectedScrapedIndices.clear();
      _scrapedWebsiteUrl = '';
      _scrapedStrategyUsed = '';
      _isScrapedDrawerOpen = false;
      _isScrapingWebsite = false;

      _isCompanyNameFocused = false;
      _companyNameFocusNode.unfocus();

      _feedback = FeedbackData(
        type: 'success',
        title: 'Company Autofilled',
        message:
            'Form populated with template details from "${company.companyName}". Review and submit when ready.',
      );
    });
  }

  // --- Edit & Form Reset Handlers ---
  void _startEdit(CompanyResponse company) {
    setState(() {
      _editingCompanyId = company.id;
      _activeTab = 'register';
      _feedback = null;

      _nameController.text = company.companyName;
      _emailController.text = company.email;
      _landlineController.text = company.landline ?? '';
      _addressController.text = company.address ?? '';
      _cityController.text = company.city ?? '';
      _countryController.text = _normalizeCountry(company.country);
      _websiteController.text = company.website ?? '';
      _descriptionController.text = company.description ?? '';
      _status = company.status;
      _contactNameController.text = company.contactName ?? '';
      _contactDesignationController.text = company.contactDesignation ?? '';
      _contactEmailController.text = company.contactEmail ?? '';
      _contactMobileController.text = company.contactMobileNumber ?? '';

      final bIds = company.brandIds.isNotEmpty
          ? List<int>.from(company.brandIds)
          : company.brands.map((b) => b.id).toList();
      _selectedBrandIds = bIds;
      _manuallySelectedBrandIds.clear();
      _manuallySelectedBrandIds.addAll(bIds);

      final pIds = company.productIds.isNotEmpty
          ? List<int>.from(company.productIds)
          : company.products.map((p) => p.id).toList();
      _selectedProductIds = pIds;

      _selectedFileBytes = null;
      _selectedFileName = null;
      _selectedFileSize = null;
      _selectedFilePath = null;
      _existingFileUrl =
          company.businessCard != null && company.businessCard!.isNotEmpty
          ? _companyService.getFileUrl(company.businessCard)
          : null;

      _scrapedProducts.clear();
      _selectedScrapedIndices.clear();
      _scrapedWebsiteUrl = '';
      _scrapedStrategyUsed = '';
      _isScrapedDrawerOpen = false;
      _isScrapingWebsite = false;

      if (_selectedCompany != null) _selectedCompany = null;
    });
  }

  void _resetFormFields() {
    _editingCompanyId = null;
    _nameController.clear();
    _emailController.clear();
    _landlineController.clear();
    _addressController.clear();
    _cityController.clear();
    _countryController.text = 'USA - United States';
    _websiteController.clear();
    _descriptionController.clear();
    _status = 'ACTIVE';
    _contactNameController.clear();
    _contactDesignationController.clear();
    _contactEmailController.clear();
    _contactMobileController.clear();

    _selectedBrandIds.clear();
    _manuallySelectedBrandIds.clear();
    _selectedProductIds.clear();
    _brandSearchQuery = '';
    _productSearchQuery = '';
    _activeProductBrandFilter = 'all';
    _activeProductCategoryFilter = 'all';
    _activeProductSubCategoryFilter = 'all';

    _selectedFileBytes = null;
    _selectedFileName = null;
    _selectedFileSize = null;
    _selectedFilePath = null;
    _existingFileUrl = null;

    _scrapedProducts.clear();
    _selectedScrapedIndices.clear();
    _scrapedWebsiteUrl = '';
    _scrapedStrategyUsed = '';
    _isScrapedDrawerOpen = false;
    _isScrapingWebsite = false;
  }

  void _resetForm() {
    setState(() {
      _resetFormFields();
    });
  }

  void _switchToRegister() {
    setState(() {
      _resetFormFields();
      _activeTab = 'register';
    });
  }

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) {
      setState(() {
        _feedback = FeedbackData(
          type: 'error',
          title: 'Validation Error',
          message:
              'Please fill in all mandatory fields correctly before proceeding.',
        );
      });
      return;
    }

    setState(() {
      _isSubmitting = true;
      _feedback = null;
    });

    final allBrandIds = {
      ..._selectedBrandIds,
      ..._selectedProductsList.map((p) => p.brandId),
    }.toList();

    final request = CompanyRequest(
      companyName: _nameController.text.trim(),
      email: _emailController.text.trim(),
      landline: _landlineController.text.trim().isNotEmpty
          ? _landlineController.text.trim()
          : null,
      address: _addressController.text.trim().isNotEmpty
          ? _addressController.text.trim()
          : null,
      city: _cityController.text.trim().isNotEmpty
          ? _cityController.text.trim()
          : null,
      country: _countryController.text.trim().isNotEmpty
          ? _countryController.text.trim()
          : null,
      website: _websiteController.text.trim().isNotEmpty
          ? _websiteController.text.trim()
          : null,
      description: _descriptionController.text.trim().isNotEmpty
          ? _descriptionController.text.trim()
          : null,
      status: _status,
      contactName: _contactNameController.text.trim().isNotEmpty
          ? _contactNameController.text.trim()
          : null,
      contactDesignation: _contactDesignationController.text.trim().isNotEmpty
          ? _contactDesignationController.text.trim()
          : null,
      contactEmail: _contactEmailController.text.trim().isNotEmpty
          ? _contactEmailController.text.trim()
          : null,
      contactMobileNumber: _contactMobileController.text.trim().isNotEmpty
          ? _contactMobileController.text.trim()
          : null,
      brandIds: allBrandIds,
      productIds: _selectedProductIds,
    );

    try {
      if (_editingCompanyId != null) {
        final response = await _companyService.updateCompany(
          _editingCompanyId!,
          request,
          fileBytes: _selectedFileBytes,
          fileName: _selectedFileName,
          filePath: _selectedFilePath,
        );
        setState(() {
          _isSubmitting = false;
          _feedback = FeedbackData(
            type: 'success',
            title: 'Company Updated Successfully!',
            message:
                'Changes for "${response.companyName}" (ID #${response.id}) have been saved.',
          );
          _resetFormFields();
          _activeTab = 'directory';
        });
        _fetchCompanies();
      } else {
        final response = await _companyService.createCompany(
          request,
          fileBytes: _selectedFileBytes,
          fileName: _selectedFileName,
          filePath: _selectedFilePath,
        );
        setState(() {
          _isSubmitting = false;
          _feedback = FeedbackData(
            type: 'success',
            title: 'Company Registered Successfully!',
            message:
                '"${response.companyName}" has been established with ID #${response.id}.',
          );
          _resetFormFields();
          _activeTab = 'directory';
        });
        _fetchCompanies();
      }
    } catch (e) {
      setState(() {
        _isSubmitting = false;
        _feedback = FeedbackData(
          type: 'error',
          title: _editingCompanyId != null
              ? 'Update Failed'
              : 'Registration Failed',
          message: e.toString().replaceAll('Exception: ', ''),
        );
      });
    }
  }

  Future<void> _exportToExcel() async {
    if (_isExportingExcel) return;
    setState(() => _isExportingExcel = true);
    try {
      final bytes = await _companyService.exportCompaniesToExcel();
      final now = DateTime.now();
      final dateStr =
          '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final fileName = 'companies_directory_$dateStr.xlsx';
      final xFile = XFile.fromData(
        bytes,
        name: fileName,
        mimeType:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      );
      await Share.shareXFiles(
        [xFile],
        text: 'Companies Directory Spreadsheet ($dateStr)',
        subject: 'Companies Directory Spreadsheet',
      );
      if (mounted) {
        setState(() {
          _isExportingExcel = false;
          _feedback = FeedbackData(
            type: 'success',
            title: 'Excel Export Successful',
            message:
                'Companies directory spreadsheet exported (${(bytes.length / 1024).toStringAsFixed(1)} KB).',
          );
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isExportingExcel = false;
          _feedback = FeedbackData(
            type: 'error',
            title: 'Export Failed',
            message:
                'Could not export Excel file: ${e.toString().replaceAll('Exception: ', '')}',
          );
        });
      }
    }
  }

  Future<void> _exportToPdf() async {
    if (_isExportingPdf) return;
    setState(() => _isExportingPdf = true);
    try {
      final bytes = await _companyService.exportCompaniesToPdf();
      final now = DateTime.now();
      final dateStr =
          '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
      final fileName = 'companies_directory_$dateStr.pdf';
      final xFile = XFile.fromData(
        bytes,
        name: fileName,
        mimeType: 'application/pdf',
      );
      await Share.shareXFiles(
        [xFile],
        text: 'Companies Directory Official PDF Document ($dateStr)',
        subject: 'Companies Directory PDF',
      );
      if (mounted) {
        setState(() {
          _isExportingPdf = false;
          _feedback = FeedbackData(
            type: 'success',
            title: 'PDF Export Successful',
            message:
                'Companies directory official PDF document exported (${(bytes.length / 1024).toStringAsFixed(1)} KB).',
          );
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isExportingPdf = false;
          _feedback = FeedbackData(
            type: 'error',
            title: 'Export Failed',
            message:
                'Could not export PDF document: ${e.toString().replaceAll('Exception: ', '')}',
          );
        });
      }
    }
  }

  Future<void> _downloadCompanyPdf(CompanyResponse company) async {
    try {
      setState(() {
        _feedback = FeedbackData(
          type: 'info',
          title: 'Generating PDF',
          message:
              'Generating executive PDF profile for ${company.companyName}...',
        );
      });
      final bytes = await _companyService.exportCompanyProfilePdf(company.id);
      final safeName = company.companyName.replaceAll(
        RegExp(r'[^a-zA-Z0-9_-]'),
        '_',
      );
      final fileName = '${safeName}_Profile_with_Cards.pdf';
      final xFile = XFile.fromData(
        bytes,
        name: fileName,
        mimeType: 'application/pdf',
      );
      await Share.shareXFiles([xFile], text: '${company.companyName} Profile');
      if (mounted) {
        setState(() {
          _feedback = FeedbackData(
            type: 'success',
            title: 'PDF Export Ready',
            message:
                'Exported executive PDF profile for ${company.companyName}.',
          );
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _feedback = FeedbackData(
            type: 'error',
            title: 'Export Failed',
            message: 'Could not generate company PDF profile: $e',
          );
        });
      }
    }
  }

  void _shareCurrentPreview() {
    final previewCompany = CompanyResponse(
      id: _editingCompanyId ?? 0,
      companyName: _nameController.text.trim().isNotEmpty
          ? _nameController.text.trim()
          : 'Untitled Company',
      email: _emailController.text.trim(),
      landline: _landlineController.text.trim().isNotEmpty
          ? _landlineController.text.trim()
          : null,
      address: _addressController.text.trim().isNotEmpty
          ? _addressController.text.trim()
          : null,
      city: _cityController.text.trim().isNotEmpty
          ? _cityController.text.trim()
          : null,
      country: _countryController.text.trim().isNotEmpty
          ? _countryController.text.trim()
          : null,
      website: _websiteController.text.trim().isNotEmpty
          ? _websiteController.text.trim()
          : null,
      description: _descriptionController.text.trim().isNotEmpty
          ? _descriptionController.text.trim()
          : null,
      contactName: _contactNameController.text.trim().isNotEmpty
          ? _contactNameController.text.trim()
          : null,
      contactDesignation: _contactDesignationController.text.trim().isNotEmpty
          ? _contactDesignationController.text.trim()
          : null,
      contactEmail: _contactEmailController.text.trim().isNotEmpty
          ? _contactEmailController.text.trim()
          : null,
      contactMobileNumber: _contactMobileController.text.trim().isNotEmpty
          ? _contactMobileController.text.trim()
          : null,
      status: _status,
      businessCard: _selectedFileName,
      brands: _availableBrands
          .where((b) => _selectedBrandIds.contains(b.id))
          .toList(),
      products: _availableProducts
          .where((p) => _selectedProductIds.contains(p.id))
          .toList(),
    );
    CompanyShareDialog.show(context, previewCompany);
  }

  void _promptDelete(CompanyResponse company) {
    showDialog(
      context: context,
      builder: (_) => DeleteConfirmDialog(
        title: 'Delete Company Record?',
        itemName: company.companyName,
        itemId: company.id,
        onConfirm: () async {
          await _companyService.deleteCompany(company.id);
          if (mounted) {
            setState(() {
              _feedback = FeedbackData(
                type: 'success',
                title: 'Company Deleted',
                message:
                    '"${company.companyName}" has been successfully deleted.',
              );
              if (_selectedCompany?.id == company.id) {
                _selectedCompany = null;
              }
              if (_editingCompanyId == company.id) {
                _resetFormFields();
              }
            });
            _fetchCompanies();
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDesktop = MediaQuery.of(context).size.width >= 1024;

    return Scaffold(
      backgroundColor: AppTheme.bgPage,
      body: Stack(
        children: [
          Column(
            children: [
              _buildTopNavTabs(),
              if (_feedback != null)
                FeedbackToast(
                  feedback: _feedback!,
                  onClose: () => setState(() => _feedback = null),
                ),
              Expanded(
                child: _activeTab == 'register'
                    ? (isDesktop
                          ? _buildDesktopRegisterView()
                          : _buildMobileRegisterView())
                    : _buildDirectoryView(),
              ),
            ],
          ),

          // View Detail Modal Dialog
          if (_selectedCompany != null)
            _buildCompanyDetailModal(_selectedCompany!),
        ],
      ),
    );
  }

  // --- Top Navigation Tabs Bar ---
  Widget _buildTopNavTabs() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: const BoxDecoration(
        color: AppTheme.bgSurface,
        border: Border(
          bottom: BorderSide(color: AppTheme.borderLight, width: 1),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            // Register Company Button
            InkWell(
              onTap: _switchToRegister,
              borderRadius: BorderRadius.circular(10),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: _activeTab == 'register' && _editingCompanyId == null
                      ? AppTheme.primaryLight
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _activeTab == 'register' && _editingCompanyId == null
                        ? AppTheme.primary.withValues(alpha: 0.3)
                        : Colors.transparent,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.add_circle,
                      size: 15,
                      color:
                          _activeTab == 'register' && _editingCompanyId == null
                          ? AppTheme.primary
                          : AppTheme.textSecondary,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'Register Company',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color:
                            _activeTab == 'register' &&
                                _editingCompanyId == null
                            ? AppTheme.primary
                            : AppTheme.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Edit Company Pill
            if (_editingCompanyId != null) ...[
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.warningBg,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: AppTheme.warning.withValues(alpha: 0.4),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    InkWell(
                      onTap: () => setState(() => _activeTab = 'register'),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.edit,
                            size: 13,
                            color: AppTheme.warning,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Edit #$_editingCompanyId',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFFB45309),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 5),
                    InkWell(
                      onTap: _switchToRegister,
                      borderRadius: BorderRadius.circular(10),
                      child: const Icon(
                        Icons.close,
                        size: 13,
                        color: Color(0xFFB45309),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
            ],

            // Directory Tab Button
            InkWell(
              onTap: () => setState(() => _activeTab = 'directory'),
              borderRadius: BorderRadius.circular(10),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: _activeTab == 'directory'
                      ? AppTheme.primaryLight
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _activeTab == 'directory'
                        ? AppTheme.primary.withValues(alpha: 0.3)
                        : Colors.transparent,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.grid_view_rounded,
                      size: 15,
                      color: _activeTab == 'directory'
                          ? AppTheme.primary
                          : AppTheme.textSecondary,
                    ),
                    const SizedBox(width: 5),
                    Text(
                      'Directory',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: _activeTab == 'directory'
                            ? AppTheme.primary
                            : AppTheme.textSecondary,
                      ),
                    ),
                    const SizedBox(width: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: _activeTab == 'directory'
                            ? AppTheme.primary
                            : AppTheme.bgSubtle,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '${_companies.length}',
                        style: GoogleFonts.inter(
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          color: _activeTab == 'directory'
                              ? Colors.white
                              : AppTheme.textSecondary,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- TAB 1: REGISTRATION / EDIT VIEW (DESKTOP) ---
  Widget _buildDesktopRegisterView() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 6,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: _buildFormContent(),
          ),
        ),
        Expanded(
          flex: 4,
          child: SingleChildScrollView(
            padding: const EdgeInsets.fromLTRB(0, 24, 24, 24),
            child: _buildLivePreviewSidebar(),
          ),
        ),
      ],
    );
  }

  // --- TAB 1: REGISTRATION / EDIT VIEW (MOBILE) ---
  Widget _buildMobileRegisterView() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Live Preview Toggle for mobile
          Container(
            margin: const EdgeInsets.only(bottom: 16),
            child: InkWell(
              onTap: () => setState(() => _showLivePreview = !_showLivePreview),
              borderRadius: BorderRadius.circular(12),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: _showLivePreview
                      ? AppTheme.primaryLight
                      : AppTheme.bgSurface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _showLivePreview
                        ? AppTheme.primary
                        : AppTheme.borderLight,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _showLivePreview
                          ? Icons.visibility_off
                          : Icons.visibility,
                      size: 18,
                      color: AppTheme.primary,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _showLivePreview
                            ? 'Hide Live Card Preview'
                            : 'Show Live Card Preview',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                    Icon(
                      _showLivePreview ? Icons.expand_less : Icons.expand_more,
                      size: 18,
                      color: AppTheme.primary,
                    ),
                  ],
                ),
              ),
            ),
          ),

          if (_showLivePreview) ...[
            _buildLivePreviewSidebar(),
            const SizedBox(height: 20),
          ],

          _buildFormContent(),
        ],
      ),
    );
  }

  // --- Form Content ---
  Widget _buildFormContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeaderBanner(),
        const SizedBox(height: 16),

        if (_editingCompanyId != null) ...[
          _buildEditingNoticeBanner(),
          const SizedBox(height: 16),
        ],

        // Smart Visiting Card Auto-Fill Banner (Matching Angular)
        BusinessCardOcrBanner(
          onUploadPressed: _handleOcrCardUpload,
          isLoading: _isOcrPicking,
        ),
        const SizedBox(height: 16),

        Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Section 01: Corporate Identity & Status
              _buildFormCard(
                stepNum: '01',
                title: 'Corporate Information',
                subtitle:
                    'Official registered enterprise identity & operational status',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Quick Template Autofill Option for New Registrations
                    if (_editingCompanyId == null) ...[
                      FastAutofillBanner(
                        companies: _companies,
                        onAutofill: _autofillFormWithCompany,
                      ),
                      const SizedBox(height: 14),
                    ],

                    Text(
                      'Company Name *',
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextFormField(
                      controller: _nameController,
                      focusNode: _companyNameFocusNode,
                      style: GoogleFonts.inter(fontSize: 14),
                      decoration: InputDecoration(
                        hintText: 'e.g. Apex Global Technologies Inc.',
                        prefixIcon: const Icon(
                          Icons.apartment,
                          size: 18,
                          color: AppTheme.textMuted,
                        ),
                      ),
                      onChanged: (_) => setState(() {}),
                      validator: (val) {
                        if (val == null || val.trim().length < 2) {
                          return 'Valid company name is required (min 2 characters)';
                        }
                        return null;
                      },
                    ),

                    // Live Search Suggestions Dropdown
                    if (_isCompanyNameFocused && _companyNameSuggestions.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      _buildCompanyNameSuggestionsDropdown(),
                    ],

                    // Exact Match / Duplicate Notice
                    if (_exactMatchedCompany != null) ...[
                      const SizedBox(height: 8),
                      _buildDuplicateCompanyNotice(_exactMatchedCompany!),
                    ],

                    const SizedBox(height: 16),

                    Text(
                      'Company Operational Status',
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        _buildStatusRadioCard('ACTIVE', AppTheme.success),
                        const SizedBox(width: 6),
                        _buildStatusRadioCard('PENDING', AppTheme.warning),
                        const SizedBox(width: 6),
                        _buildStatusRadioCard('INACTIVE', AppTheme.textMuted),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),

              // Section 02: Primary Contact Person
              _buildFormCard(
                stepNum: '02',
                title: 'Contact Person & Representative',
                subtitle:
                    'Key executive or point-of-contact details for this enterprise',
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isNarrow = constraints.maxWidth < 500;
                    return Column(
                      children: [
                        Flex(
                          direction: isNarrow ? Axis.vertical : Axis.horizontal,
                          children: [
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Contact Person Name',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _contactNameController,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: 'e.g. Sarah Jenkins',
                                      prefixIcon: const Icon(
                                        Icons.badge_outlined,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: isNarrow ? 0 : 12,
                              height: isNarrow ? 12 : 0,
                            ),
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Designation / Role',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _contactDesignationController,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: 'e.g. Managing Director / CTO',
                                      prefixIcon: const Icon(
                                        Icons.work_outline,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Flex(
                          direction: isNarrow ? Axis.vertical : Axis.horizontal,
                          children: [
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Contact Person Email',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _contactEmailController,
                                    keyboardType: TextInputType.emailAddress,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: 'sarah.jenkins@company.com',
                                      prefixIcon: const Icon(
                                        Icons.email_outlined,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: isNarrow ? 0 : 12,
                              height: isNarrow ? 12 : 0,
                            ),
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Mobile Number',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _contactMobileController,
                                    keyboardType: TextInputType.phone,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: '+1 (555) 987-6543',
                                      prefixIcon: const Icon(
                                        Icons.phone_iphone,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),

              // Section 03: Corporate Communication & Web
              _buildFormCard(
                stepNum: '03',
                title: 'Corporate Communication & Web',
                subtitle:
                    'Official company-wide channels and public web portal',
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isNarrow = constraints.maxWidth < 500;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Flex(
                          direction: isNarrow ? Axis.vertical : Axis.horizontal,
                          children: [
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Corporate Email *',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _emailController,
                                    keyboardType: TextInputType.emailAddress,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: 'contact@enterprise.com',
                                      prefixIcon: const Icon(
                                        Icons.alternate_email,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                    validator: (val) {
                                      if (val == null || !val.contains('@')) {
                                        return 'Valid corporate email is required';
                                      }
                                      return null;
                                    },
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              width: isNarrow ? 0 : 12,
                              height: isNarrow ? 12 : 0,
                            ),
                            Expanded(
                              flex: isNarrow ? 0 : 1,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Landline Number',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  TextFormField(
                                    controller: _landlineController,
                                    keyboardType: TextInputType.phone,
                                    style: GoogleFonts.inter(fontSize: 13),
                                    decoration: InputDecoration(
                                      hintText: '+1 (555) 019-2834',
                                      prefixIcon: const Icon(
                                        Icons.phone_in_talk,
                                        size: 18,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    onChanged: (_) => setState(() {}),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  child: Text(
                                    'Official Website',
                                    style: GoogleFonts.inter(
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                ),
                                if (_websiteController.text
                                    .trim()
                                    .isNotEmpty) ...[
                                  const SizedBox(width: 8),
                                  InkWell(
                                    onTap: _isScrapingWebsite
                                        ? null
                                        : _triggerWebsiteProductScrape,
                                    borderRadius: BorderRadius.circular(20),
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 10,
                                        vertical: 4,
                                      ),
                                      decoration: BoxDecoration(
                                        gradient: const LinearGradient(
                                          colors: [
                                            Color(0xFFE0E7FF),
                                            Color(0xFFEDE9FE),
                                          ],
                                        ),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color: const Color(0xFFC7D2FE),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (_isScrapingWebsite) ...[
                                            const SizedBox(
                                              width: 12,
                                              height: 12,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                valueColor:
                                                    AlwaysStoppedAnimation<
                                                      Color
                                                    >(Color(0xFF4338CA)),
                                              ),
                                            ),
                                            const SizedBox(width: 6),
                                            Text(
                                              'Scanning...',
                                              style: GoogleFonts.inter(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: const Color(0xFF4338CA),
                                              ),
                                            ),
                                          ] else ...[
                                            const Icon(
                                              Icons.auto_awesome,
                                              size: 13,
                                              color: Color(0xFF4338CA),
                                            ),
                                            const SizedBox(width: 5),
                                            Text(
                                              'Discover Products',
                                              style: GoogleFonts.inter(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: const Color(0xFF4338CA),
                                              ),
                                            ),
                                          ],
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 6),
                            TextFormField(
                              controller: _websiteController,
                              keyboardType: TextInputType.url,
                              style: GoogleFonts.inter(fontSize: 13),
                              decoration: InputDecoration(
                                hintText: 'https://company.example.com',
                                prefixIcon: const Icon(
                                  Icons.language,
                                  size: 18,
                                  color: AppTheme.textMuted,
                                ),
                              ),
                              onChanged: (_) => setState(() {}),
                            ),
                            if (_scrapedProducts.isNotEmpty)
                              InkWell(
                                onTap: _openScrapedDrawerWithScroll,
                                borderRadius: BorderRadius.circular(20),
                                child: Container(
                                  margin: const EdgeInsets.only(top: 8),
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 5,
                                  ),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFD1FAE5),
                                    borderRadius: BorderRadius.circular(20),
                                    border: Border.all(
                                      color: const Color(0xFFA7F3D0),
                                    ),
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      const Icon(
                                        Icons.check_circle,
                                        size: 14,
                                        color: Color(0xFF065F46),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        '${_scrapedProducts.length} products discovered',
                                        style: GoogleFonts.inter(
                                          fontSize: 11.5,
                                          fontWeight: FontWeight.w600,
                                          color: const Color(0xFF065F46),
                                        ),
                                      ),
                                      const SizedBox(width: 6),
                                      Text(
                                        'View List',
                                        style: GoogleFonts.inter(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                          color: const Color(0xFF047857),
                                          decoration: TextDecoration.underline,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),

              // Section 04: Headquarters Address
              _buildFormCard(
                stepNum: '04',
                title: 'Corporate Headquarters',
                subtitle: 'Registered office address and country jurisdiction',
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    final isNarrow = constraints.maxWidth < 500;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Street Address',
                          style: GoogleFonts.inter(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 6),
                        TextFormField(
                          controller: _addressController,
                          style: GoogleFonts.inter(fontSize: 13),
                          decoration: InputDecoration(
                            hintText: 'Suite 500, 100 Innovation Way',
                            isDense: true,
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            prefixIcon: const Icon(
                              Icons.location_on_outlined,
                              size: 18,
                              color: AppTheme.textMuted,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: AppTheme.borderMedium,
                                width: 1,
                              ),
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: AppTheme.borderLight,
                                width: 1,
                              ),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: const BorderSide(
                                color: AppTheme.primary,
                                width: 1.5,
                              ),
                            ),
                          ),
                          onChanged: (_) => setState(() {}),
                        ),
                        const SizedBox(height: 12),
                        if (isNarrow) ...[
                          _buildCityField(),
                          const SizedBox(height: 12),
                          _buildCountryDropdownField(),
                        ] else ...[
                          Row(
                            children: [
                              Expanded(child: _buildCityField()),
                              const SizedBox(width: 12),
                              Expanded(child: _buildCountryDropdownField()),
                            ],
                          ),
                        ],
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 16),

              // Section 05: Brands Dealt With & Partner Dealerships
              _buildFormCard(
                stepNum: '05',
                title: 'Brands Dealt With & Partner Dealerships',
                subtitle:
                    'Select the manufacturer brands this enterprise deals with, represents, or distributes',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Filter & Helper Action Bar
                    LayoutBuilder(
                      builder: (context, constraints) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 36,
                              child: TextField(
                                style: GoogleFonts.inter(fontSize: 12),
                                decoration: InputDecoration(
                                  hintText: 'Filter brands by name...',
                                  prefixIcon: const Icon(
                                    Icons.search,
                                    size: 15,
                                    color: AppTheme.textMuted,
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                onChanged: (val) =>
                                    setState(() => _brandSearchQuery = val),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Text(
                                  '${_selectedBrandIds.length}/${_availableBrands.length} selected',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                                OutlinedButton(
                                  onPressed: _availableBrands.isEmpty
                                      ? null
                                      : _selectAllBrands,
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 6,
                                    ),
                                    textStyle: GoogleFonts.inter(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text('Select All'),
                                ),
                                OutlinedButton(
                                  onPressed: _selectedBrandIds.isEmpty
                                      ? null
                                      : _clearSelectedBrands,
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 10,
                                      vertical: 6,
                                    ),
                                    textStyle: GoogleFonts.inter(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text('Clear'),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 12),

                    if (_isLoadingBrands)
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: CircularProgressIndicator(),
                        ),
                      )
                    else if (_availableBrands.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'No brands registered in the system yet. Register brands first so companies can select them.',
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            color: AppTheme.textMuted,
                          ),
                        ),
                      )
                    else if (_filteredAvailableBrands.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.center,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.filter_alt_off,
                              size: 28,
                              color: AppTheme.textMuted,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'No brands match current search.',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                color: AppTheme.textMuted,
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filteredAvailableBrands.length,
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 6),
                        itemBuilder: (context, index) {
                          final b = _filteredAvailableBrands[index];
                          final isSelected = _selectedBrandIds.contains(b.id);
                          final brandProdsCount = _availableProducts
                              .where((p) => p.brandId == b.id)
                              .length;

                          return Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _toggleBrand(b.id),
                              borderRadius: BorderRadius.circular(10),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppTheme.primaryLight.withOpacity(0.55)
                                      : AppTheme.bgSurface,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: isSelected
                                        ? AppTheme.primary
                                        : AppTheme.borderLight,
                                    width: isSelected ? 1.5 : 1,
                                  ),
                                  boxShadow: isSelected
                                      ? [
                                          BoxShadow(
                                            color: AppTheme.primary.withOpacity(
                                              0.06,
                                            ),
                                            blurRadius: 6,
                                            offset: const Offset(0, 2),
                                          ),
                                        ]
                                      : AppTheme.shadowSm,
                                ),
                                child: Row(
                                  children: [
                                    // Custom Checkbox
                                    AnimatedContainer(
                                      duration: const Duration(
                                        milliseconds: 150,
                                      ),
                                      width: 18,
                                      height: 18,
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? AppTheme.primary
                                            : Colors.transparent,
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(
                                          color: isSelected
                                              ? AppTheme.primary
                                              : AppTheme.borderMedium,
                                          width: 1.2,
                                        ),
                                      ),
                                      child: isSelected
                                          ? const Icon(
                                              Icons.check_rounded,
                                              size: 13,
                                              color: Colors.white,
                                            )
                                          : null,
                                    ),
                                    const SizedBox(width: 8),

                                    // Brand Logo / Initial Avatar
                                    Container(
                                      width: 36,
                                      height: 36,
                                      decoration: BoxDecoration(
                                        color: AppTheme.bgSubtle,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: isSelected
                                              ? AppTheme.primary.withOpacity(
                                                  0.3,
                                                )
                                              : AppTheme.borderLight,
                                        ),
                                      ),
                                      clipBehavior: Clip.antiAlias,
                                      child:
                                          (b.brandLogo != null &&
                                              b.brandLogo!.isNotEmpty)
                                          ? Image.network(
                                              _brandService.getFileUrl(
                                                b.brandLogo,
                                              ),
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (
                                                    context,
                                                    error,
                                                    stackTrace,
                                                  ) => Center(
                                                    child: Text(
                                                      b.initials,
                                                      style:
                                                          GoogleFonts.plusJakartaSans(
                                                            fontSize: 12,
                                                            fontWeight:
                                                                FontWeight.w700,
                                                            color: AppTheme
                                                                .primary,
                                                          ),
                                                    ),
                                                  ),
                                            )
                                          : Center(
                                              child: Text(
                                                b.initials,
                                                style:
                                                    GoogleFonts.plusJakartaSans(
                                                      fontSize: 12,
                                                      fontWeight:
                                                          FontWeight.w700,
                                                      color: AppTheme.primary,
                                                    ),
                                              ),
                                            ),
                                    ),
                                    const SizedBox(width: 8),

                                    // Brand Details
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Row(
                                            children: [
                                              Flexible(
                                                child: Text(
                                                  b.brandName,
                                                  style:
                                                      GoogleFonts.plusJakartaSans(
                                                        fontSize: 12.5,
                                                        fontWeight: isSelected
                                                            ? FontWeight.w700
                                                            : FontWeight.w600,
                                                        color: isSelected
                                                            ? AppTheme.primary
                                                            : AppTheme
                                                                  .textPrimary,
                                                      ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                              if (b.isFeatured) ...[
                                                const SizedBox(width: 4),
                                                Container(
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 5,
                                                        vertical: 1.5,
                                                      ),
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFFFEF3C7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          4,
                                                        ),
                                                    border: Border.all(
                                                      color: const Color(
                                                        0xFFFDE68A,
                                                      ),
                                                    ),
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      const Icon(
                                                        Icons.star_rounded,
                                                        size: 10,
                                                        color: Color(
                                                          0xFFD97706,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 1.5,
                                                      ),
                                                      Text(
                                                        'Featured',
                                                        style:
                                                            GoogleFonts.inter(
                                                              fontSize: 8.5,
                                                              color:
                                                                  const Color(
                                                                    0xFFB45309,
                                                                  ),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                            ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ],
                                          ),
                                          const SizedBox(height: 2),
                                          Row(
                                            children: [
                                              const Icon(
                                                Icons.inventory_2_outlined,
                                                size: 11,
                                                color: AppTheme.textMuted,
                                              ),
                                              const SizedBox(width: 3.5),
                                              Expanded(
                                                child: Text(
                                                  '$brandProdsCount ${brandProdsCount == 1 ? 'product' : 'products'}',
                                                  style: GoogleFonts.inter(
                                                    fontSize: 10,
                                                    color:
                                                        AppTheme.textSecondary,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),

                                    // Selection status indicator badge
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 3.5,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? AppTheme.primary
                                            : AppTheme.bgSubtle,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (isSelected) ...[
                                            const Icon(
                                              Icons.check_rounded,
                                              size: 11,
                                              color: Colors.white,
                                            ),
                                            const SizedBox(width: 2.5),
                                          ],
                                          Text(
                                            isSelected ? 'Selected' : 'Select',
                                            style: GoogleFonts.inter(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w600,
                                              color: isSelected
                                                  ? Colors.white
                                                  : AppTheme.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Section 06: Authorized Products Catalog (From Brands through Categories)
              _buildFormCard(
                stepNum: '06',
                title: 'Authorized Products Catalog',
                subtitle:
                    'Choose products from brands through categories that this enterprise offers or distributes',
                action: _websiteController.text.trim().isNotEmpty
                    ? InkWell(
                        onTap: _isScrapingWebsite
                            ? null
                            : _triggerWebsiteProductScrape,
                        borderRadius: BorderRadius.circular(20),
                        child: Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            gradient: const LinearGradient(
                              colors: [Color(0xFFEEF2FF), Color(0xFFFAF5FF)],
                            ),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: const Color(0xFFC7D2FE),
                              width: 1.5,
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              if (_isScrapingWebsite) ...[
                                const SizedBox(
                                  width: 12,
                                  height: 12,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      Color(0xFF4F46E5),
                                    ),
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(
                                  'Scraping Website...',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFF4F46E5),
                                  ),
                                ),
                              ] else ...[
                                const Icon(
                                  Icons.auto_awesome,
                                  size: 13,
                                  color: Color(0xFF4F46E5),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'Scan Website for Products',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFF4F46E5),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      )
                    : null,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (_isScrapedDrawerOpen) ...[
                      _buildScrapedProductsDrawer(),
                      const SizedBox(height: 16),
                    ],
                    // Drilldown Filter Grid
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        // Filter by Brand
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.bgSubtle,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: AppTheme.borderLight),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _activeProductBrandFilter,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppTheme.textPrimary,
                              ),
                              items: [
                                DropdownMenuItem(
                                  value: 'all',
                                  child: Text(
                                    'All Brands (${_availableProducts.length} total)',
                                  ),
                                ),
                                ..._brandsWithProducts.map((item) {
                                  final BrandResponse b =
                                      item['brand'] as BrandResponse;
                                  final int count = item['count'] as int;
                                  return DropdownMenuItem(
                                    value: b.id.toString(),
                                    child: Text(
                                      '${b.brandName} ($count prods)',
                                    ),
                                  );
                                }),
                              ],
                              onChanged: (val) {
                                if (val != null) {
                                  setState(() {
                                    _activeProductBrandFilter = val;
                                    _activeProductCategoryFilter = 'all';
                                    _activeProductSubCategoryFilter = 'all';
                                  });
                                }
                              },
                            ),
                          ),
                        ),

                        // Filter by Category
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.bgSubtle,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: AppTheme.borderLight),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _activeProductCategoryFilter,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppTheme.textPrimary,
                              ),
                              items: [
                                DropdownMenuItem(
                                  value: 'all',
                                  child: Text(
                                    _isLoadingCategories
                                        ? 'Loading Categories...'
                                        : 'All Categories',
                                  ),
                                ),
                                ..._availableCategoriesForBrand.map((c) {
                                  return DropdownMenuItem(
                                    value: c.id.toString(),
                                    child: Text(c.name),
                                  );
                                }),
                              ],
                              onChanged: (val) {
                                if (val != null) {
                                  setState(() {
                                    _activeProductCategoryFilter = val;
                                    _activeProductSubCategoryFilter = 'all';
                                  });
                                }
                              },
                            ),
                          ),
                        ),

                        // Filter by Subcategory
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.bgSubtle,
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: AppTheme.borderLight),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _activeProductSubCategoryFilter,
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppTheme.textPrimary,
                              ),
                              items: [
                                const DropdownMenuItem(
                                  value: 'all',
                                  child: Text('All Subcategories'),
                                ),
                                ..._availableSubCategoriesForSelection.map((s) {
                                  return DropdownMenuItem(
                                    value: s.id.toString(),
                                    child: Text(s.name),
                                  );
                                }),
                              ],
                              onChanged: (val) {
                                if (val != null)
                                  setState(
                                    () => _activeProductSubCategoryFilter = val,
                                  );
                              },
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    // Product Search Input & Selection Actions Bar
                    LayoutBuilder(
                      builder: (context, constraints) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 36,
                              child: TextField(
                                style: GoogleFonts.inter(fontSize: 12),
                                decoration: InputDecoration(
                                  hintText: 'Search product name, code...',
                                  prefixIcon: const Icon(
                                    Icons.search,
                                    size: 15,
                                    color: AppTheme.textMuted,
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 10,
                                    vertical: 0,
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                ),
                                onChanged: (val) =>
                                    setState(() => _productSearchQuery = val),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 6,
                              runSpacing: 6,
                              crossAxisAlignment: WrapCrossAlignment.center,
                              children: [
                                Text(
                                  '${_selectedProductIds.length}/${_availableProducts.length} chosen',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: AppTheme.textSecondary,
                                  ),
                                ),
                                OutlinedButton(
                                  onPressed: _filteredAvailableProducts.isEmpty
                                      ? null
                                      : _selectAllFilteredProducts,
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 6,
                                    ),
                                    textStyle: GoogleFonts.inter(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: Text(
                                    'Select (${_filteredAvailableProducts.length})',
                                  ),
                                ),
                                OutlinedButton(
                                  onPressed: _filteredAvailableProducts.isEmpty
                                      ? null
                                      : _deselectFilteredProducts,
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 6,
                                    ),
                                    textStyle: GoogleFonts.inter(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text('Deselect'),
                                ),
                                OutlinedButton(
                                  onPressed: _selectedProductIds.isEmpty
                                      ? null
                                      : _clearSelectedProducts,
                                  style: OutlinedButton.styleFrom(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 6,
                                    ),
                                    textStyle: GoogleFonts.inter(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                  ),
                                  child: const Text('Clear'),
                                ),
                              ],
                            ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 10),

                    // Selected Products Pills Strip
                    if (_selectedProductIds.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 6,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          crossAxisAlignment: WrapCrossAlignment.center,
                          children: [
                            Text(
                              'Selected (${_selectedProductIds.length}):',
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                            ..._selectedProductsList.map((p) {
                              return Container(
                                padding: const EdgeInsets.fromLTRB(8, 3, 4, 3),
                                decoration: BoxDecoration(
                                  color: AppTheme.bgSurface,
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                    color: AppTheme.borderMedium,
                                  ),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    Text(
                                      p.name,
                                      style: GoogleFonts.inter(
                                        fontSize: 11,
                                        fontWeight: FontWeight.w600,
                                        color: AppTheme.textPrimary,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    Text(
                                      '(${p.brandName ?? ''})',
                                      style: GoogleFonts.inter(
                                        fontSize: 10,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                    const SizedBox(width: 4),
                                    InkWell(
                                      onTap: () {
                                        setState(() {
                                          _removeProductAndCheckBrand(
                                            p.id,
                                            p.brandId,
                                          );
                                        });
                                      },
                                      child: const Icon(
                                        Icons.close,
                                        size: 14,
                                        color: AppTheme.textMuted,
                                      ),
                                    ),
                                  ],
                                ),
                              );
                            }),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],

                    // Products Selection Grid
                    if (_isLoadingProducts)
                      const Center(
                        child: Padding(
                          padding: EdgeInsets.all(20),
                          child: CircularProgressIndicator(),
                        ),
                      )
                    else if (_availableProducts.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          'No products available yet. Register products first.',
                          style: GoogleFonts.inter(
                            fontSize: 12,
                            color: AppTheme.textMuted,
                          ),
                        ),
                      )
                    else if (_filteredAvailableProducts.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        alignment: Alignment.center,
                        child: Column(
                          children: [
                            const Icon(
                              Icons.filter_alt_off,
                              size: 28,
                              color: AppTheme.textMuted,
                            ),
                            const SizedBox(height: 6),
                            Text(
                              'No products match current filters.',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                color: AppTheme.textMuted,
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      ListView.separated(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _filteredAvailableProducts.length,
                        separatorBuilder: (context, index) =>
                            const SizedBox(height: 6),
                        itemBuilder: (context, index) {
                          final p = _filteredAvailableProducts[index];
                          final isSelected = _selectedProductIds.contains(p.id);

                          return Material(
                            color: Colors.transparent,
                            child: InkWell(
                              onTap: () => _toggleProduct(p),
                              borderRadius: BorderRadius.circular(10),
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 150),
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 8,
                                ),
                                decoration: BoxDecoration(
                                  color: isSelected
                                      ? AppTheme.primaryLight.withOpacity(0.55)
                                      : AppTheme.bgSurface,
                                  borderRadius: BorderRadius.circular(10),
                                  border: Border.all(
                                    color: isSelected
                                        ? AppTheme.primary
                                        : AppTheme.borderLight,
                                    width: isSelected ? 1.5 : 1,
                                  ),
                                  boxShadow: isSelected
                                      ? [
                                          BoxShadow(
                                            color: AppTheme.primary.withOpacity(
                                              0.06,
                                            ),
                                            blurRadius: 6,
                                            offset: const Offset(0, 2),
                                          ),
                                        ]
                                      : AppTheme.shadowSm,
                                ),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    // Custom Checkbox
                                    AnimatedContainer(
                                      duration: const Duration(
                                        milliseconds: 150,
                                      ),
                                      width: 18,
                                      height: 18,
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? AppTheme.primary
                                            : Colors.transparent,
                                        borderRadius: BorderRadius.circular(4),
                                        border: Border.all(
                                          color: isSelected
                                              ? AppTheme.primary
                                              : AppTheme.borderMedium,
                                          width: 1.2,
                                        ),
                                      ),
                                      child: isSelected
                                          ? const Icon(
                                              Icons.check_rounded,
                                              size: 13,
                                              color: Colors.white,
                                            )
                                          : null,
                                    ),
                                    const SizedBox(width: 8),

                                    // Product Image
                                    Container(
                                      width: 40,
                                      height: 40,
                                      decoration: BoxDecoration(
                                        color: AppTheme.bgSubtle,
                                        borderRadius: BorderRadius.circular(8),
                                        border: Border.all(
                                          color: isSelected
                                              ? AppTheme.primary.withOpacity(
                                                  0.3,
                                                )
                                              : AppTheme.borderLight,
                                        ),
                                      ),
                                      clipBehavior: Clip.antiAlias,
                                      child:
                                          (p.image != null &&
                                              p.image!.isNotEmpty)
                                          ? Image.network(
                                              _productService.getFileUrl(
                                                p.image,
                                              ),
                                              fit: BoxFit.cover,
                                              errorBuilder:
                                                  (
                                                    context,
                                                    error,
                                                    stackTrace,
                                                  ) => const Center(
                                                    child: Icon(
                                                      Icons
                                                          .inventory_2_outlined,
                                                      size: 18,
                                                      color: AppTheme.textMuted,
                                                    ),
                                                  ),
                                            )
                                          : const Center(
                                              child: Icon(
                                                Icons.inventory_2_outlined,
                                                size: 18,
                                                color: AppTheme.textMuted,
                                              ),
                                            ),
                                    ),
                                    const SizedBox(width: 8),

                                    // Product Details
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          // Brand Tag & Featured Tag Row
                                          Row(
                                            children: [
                                              if (p.brandName != null &&
                                                  p.brandName!.isNotEmpty) ...[
                                                Flexible(
                                                  child: Container(
                                                    padding:
                                                        const EdgeInsets.symmetric(
                                                          horizontal: 5,
                                                          vertical: 1.5,
                                                        ),
                                                    decoration: BoxDecoration(
                                                      color: AppTheme.primary
                                                          .withOpacity(0.1),
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                            4,
                                                          ),
                                                    ),
                                                    child: Text(
                                                      p.brandName!,
                                                      style: GoogleFonts.inter(
                                                        fontSize: 9,
                                                        fontWeight:
                                                            FontWeight.w700,
                                                        color: AppTheme.primary,
                                                      ),
                                                      maxLines: 1,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                    ),
                                                  ),
                                                ),
                                                const SizedBox(width: 4),
                                              ],
                                              if (p.isFeatured) ...[
                                                Container(
                                                  padding:
                                                      const EdgeInsets.symmetric(
                                                        horizontal: 5,
                                                        vertical: 1.5,
                                                      ),
                                                  decoration: BoxDecoration(
                                                    color: const Color(
                                                      0xFFFEF3C7,
                                                    ),
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                          4,
                                                        ),
                                                    border: Border.all(
                                                      color: const Color(
                                                        0xFFFDE68A,
                                                      ),
                                                    ),
                                                  ),
                                                  child: Row(
                                                    mainAxisSize:
                                                        MainAxisSize.min,
                                                    children: [
                                                      const Icon(
                                                        Icons.star_rounded,
                                                        size: 10,
                                                        color: Color(
                                                          0xFFD97706,
                                                        ),
                                                      ),
                                                      const SizedBox(
                                                        width: 1.5,
                                                      ),
                                                      Text(
                                                        'Featured',
                                                        style:
                                                            GoogleFonts.inter(
                                                              fontSize: 8.5,
                                                              color:
                                                                  const Color(
                                                                    0xFFB45309,
                                                                  ),
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w700,
                                                            ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ],
                                          ),
                                          const SizedBox(height: 2),

                                          // Product Name
                                          Text(
                                            p.name,
                                            style: GoogleFonts.plusJakartaSans(
                                              fontSize: 12,
                                              fontWeight: isSelected
                                                  ? FontWeight.w700
                                                  : FontWeight.w600,
                                              color: isSelected
                                                  ? AppTheme.primary
                                                  : AppTheme.textPrimary,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                          ),
                                          const SizedBox(height: 2),

                                          // Category Path
                                          Row(
                                            children: [
                                              const Icon(
                                                Icons.category_outlined,
                                                size: 11,
                                                color: AppTheme.textMuted,
                                              ),
                                              const SizedBox(width: 3.5),
                                              Expanded(
                                                child: Text(
                                                  '${p.categoryName ?? 'General'}${p.subCategoryName != null && p.subCategoryName!.isNotEmpty ? ' › ${p.subCategoryName}' : ''}',
                                                  style: GoogleFonts.inter(
                                                    fontSize: 10,
                                                    color:
                                                        AppTheme.textSecondary,
                                                    fontWeight: FontWeight.w500,
                                                  ),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                    const SizedBox(width: 6),

                                    // Selection status indicator badge
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 8,
                                        vertical: 3.5,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isSelected
                                            ? AppTheme.primary
                                            : AppTheme.bgSubtle,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                      child: Row(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          if (isSelected) ...[
                                            const Icon(
                                              Icons.check_rounded,
                                              size: 11,
                                              color: Colors.white,
                                            ),
                                            const SizedBox(width: 2.5),
                                          ],
                                          Text(
                                            isSelected ? 'Added' : 'Add',
                                            style: GoogleFonts.inter(
                                              fontSize: 10,
                                              fontWeight: FontWeight.w600,
                                              color: isSelected
                                                  ? Colors.white
                                                  : AppTheme.textSecondary,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // Section 07: Business Card & Brand Asset Upload
              _buildFormCard(
                stepNum: '07',
                title: 'Business Card & Brand Asset',
                subtitle:
                    'Upload company logo, digital visiting card, or certificate (JPEG, PNG, WEBP, PDF)',
                child: FileUploadBox(
                  title: 'Drop your business card or company logo here',
                  hint: 'or browse files from your computer',
                  allowedExtensions: const [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp',
                    'gif',
                    'pdf',
                  ],
                  fileName: _selectedFileName,
                  fileSize: _selectedFileSize,
                  existingFileUrl: _existingFileUrl,
                  fileBytes: _selectedFileBytes,
                  onFileSelected: (bytes, name, size, path) {
                    setState(() {
                      _selectedFileBytes = bytes;
                      _selectedFileName = name;
                      _selectedFileSize = size;
                      _selectedFilePath = path;
                    });
                  },
                  onFileRemoved: () {
                    setState(() {
                      _selectedFileBytes = null;
                      _selectedFileName = null;
                      _selectedFileSize = null;
                      _selectedFilePath = null;
                      _existingFileUrl = null;
                    });
                  },
                  onOcrScan: () async {
                    if (_selectedFileBytes != null &&
                        _selectedFileName != null) {
                      _handleOcrCardUpload(
                        _selectedFileBytes,
                        _selectedFileName,
                        _selectedFileSize,
                        _selectedFilePath,
                      );
                    } else if (_existingFileUrl != null &&
                        _existingFileUrl!.isNotEmpty) {
                      try {
                        final fullUrl = ApiConfig().getFileUrl(
                          _existingFileUrl,
                        );
                        final res = await http.get(Uri.parse(fullUrl));
                        if (res.statusCode == 200) {
                          final name = _existingFileUrl!.split('/').last;
                          _handleOcrCardUpload(
                            res.bodyBytes,
                            name,
                            res.bodyBytes.length,
                            null,
                          );
                          return;
                        }
                      } catch (e) {
                        debugPrint(
                          'Could not download existing file for OCR: $e',
                        );
                      }
                      _handleOcrCardUpload();
                    } else {
                      _handleOcrCardUpload();
                    }
                  },
                ),
              ),
              const SizedBox(height: 20),

              // Section 08: Corporate Overview & Profile
              _buildFormCard(
                stepNum: '08',
                title: 'Corporate Overview & Profile',
                subtitle: 'Summary of company activities, mission, and scope',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Company Summary',
                      style: GoogleFonts.inter(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 6),
                    TextFormField(
                      controller: _descriptionController,
                      maxLines: 4,
                      maxLength: 1000,
                      style: GoogleFonts.inter(fontSize: 13),
                      decoration: const InputDecoration(
                        hintText:
                            'Briefly describe your company\'s core business, services, products, and mission...',
                        alignLabelWithHint: true,
                      ),
                      onChanged: (_) => setState(() {}),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),

              // Form Actions
              Wrap(
                spacing: 12,
                runSpacing: 12,
                alignment: WrapAlignment.end,
                children: [
                  OutlinedButton(
                    onPressed: _isSubmitting ? null : _resetForm,
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 12,
                      ),
                      side: const BorderSide(color: AppTheme.borderMedium),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _editingCompanyId != null
                                ? Icons.cancel_outlined
                                : Icons.restart_alt,
                            size: 16,
                            color: AppTheme.textSecondary,
                          ),
                          const SizedBox(width: 8),
                          Text(
                            _editingCompanyId != null
                                ? 'Cancel Edit'
                                : 'Reset Form',
                            style: GoogleFonts.plusJakartaSans(
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: _isSubmitting ? null : _handleSubmit,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 12,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      elevation: 0,
                    ),
                    child: _isSubmitting
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2,
                            ),
                          )
                        : FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  _editingCompanyId != null
                                      ? Icons.check_circle_outline
                                      : Icons.add_circle,
                                  size: 16,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  _editingCompanyId != null
                                      ? 'Update Company Details'
                                      : 'Complete Company Registration',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeaderBanner() {
    final isEdit = _editingCompanyId != null;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderLight),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              gradient: isEdit
                  ? const LinearGradient(
                      colors: [Color(0xFFF59E0B), Color(0xFFD97706)],
                    )
                  : AppTheme.primaryGradient,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: (isEdit ? const Color(0xFFF59E0B) : AppTheme.primary)
                      .withValues(alpha: 0.25),
                  blurRadius: 6,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Icon(
              isEdit ? Icons.edit_note_rounded : Icons.apartment_rounded,
              color: Colors.white,
              size: 20,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        isEdit
                            ? 'Update Company Record'
                            : 'Company Registration',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 14.5,
                          fontWeight: FontWeight.w700,
                          color: AppTheme.textPrimary,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    if (isEdit) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.warningBg,
                          borderRadius: BorderRadius.circular(6),
                          border: Border.all(
                            color: AppTheme.warning.withValues(alpha: 0.4),
                          ),
                        ),
                        child: Text(
                          'ID #$_editingCompanyId',
                          style: GoogleFonts.inter(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFFB45309),
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 2),
                Text(
                  isEdit
                      ? 'Modify official details for this registered entity.'
                      : 'Register your enterprise with official records and contacts.',
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    color: AppTheme.textSecondary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          if (isEdit) ...[
            const SizedBox(width: 8),
            InkWell(
              onTap: _switchToRegister,
              borderRadius: BorderRadius.circular(8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: AppTheme.primaryLight,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: AppTheme.primary.withValues(alpha: 0.3),
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.add_circle,
                      size: 13,
                      color: AppTheme.primary,
                    ),
                    const SizedBox(width: 4),
                    Text(
                      'New',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.primary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildEditingNoticeBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFFDE68A)),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Color(0xFFD97706), size: 16),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Editing company #$_editingCompanyId.',
              style: GoogleFonts.inter(
                fontSize: 11.5,
                fontWeight: FontWeight.w500,
                color: const Color(0xFF92400E),
              ),
            ),
          ),
          TextButton(
            onPressed: _switchToRegister,
            style: TextButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              visualDensity: VisualDensity.compact,
            ),
            child: Text(
              'Cancel / New',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: AppTheme.primary,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusRadioCard(String val, Color color) {
    final isSelected = _status == val;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => _status = val),
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 4),
          decoration: BoxDecoration(
            color: isSelected
                ? color.withValues(alpha: 0.1)
                : AppTheme.bgSurface,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: isSelected ? color : AppTheme.borderLight,
              width: isSelected ? 1.5 : 1,
            ),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 7,
                height: 7,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              ),
              const SizedBox(width: 4),
              Flexible(
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    val,
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      fontWeight: isSelected
                          ? FontWeight.w700
                          : FontWeight.w600,
                      color: isSelected ? color : AppTheme.textSecondary,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCityField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'City',
          style: GoogleFonts.inter(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        TextFormField(
          controller: _cityController,
          style: GoogleFonts.inter(fontSize: 13),
          decoration: InputDecoration(
            hintText: 'San Francisco',
            isDense: true,
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.borderMedium,
                width: 1,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.borderLight,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.primary,
                width: 1.5,
              ),
            ),
          ),
          onChanged: (_) => setState(() {}),
        ),
      ],
    );
  }

  Widget _buildCountryDropdownField() {
    final normalized = _normalizeCountry(_countryController.text);
    final items = [
      ..._countryList,
      if (!_countryList.contains(normalized)) normalized,
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Country',
          style: GoogleFonts.inter(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
        ),
        const SizedBox(height: 6),
        DropdownButtonFormField<String>(
          value: normalized,
          isExpanded: true,
          icon: const Icon(
            Icons.keyboard_arrow_down_rounded,
            size: 20,
            color: AppTheme.textMuted,
          ),
          dropdownColor: Colors.white,
          borderRadius: BorderRadius.circular(12),
          elevation: 4,
          style: GoogleFonts.inter(
            fontSize: 13,
            color: AppTheme.textPrimary,
            fontWeight: FontWeight.w500,
          ),
          decoration: InputDecoration(
            isDense: true,
            filled: true,
            fillColor: Colors.white,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 12,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.borderMedium,
                width: 1,
              ),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.borderLight,
                width: 1,
              ),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(
                color: AppTheme.primary,
                width: 1.5,
              ),
            ),
          ),
          items: items.map((c) {
            return DropdownMenuItem<String>(
              value: c,
              child: Text(
                c,
                style: GoogleFonts.inter(
                  fontSize: 13,
                  color: AppTheme.textPrimary,
                ),
                overflow: TextOverflow.ellipsis,
              ),
            );
          }).toList(),
          onChanged: (val) {
            if (val != null) {
              setState(() {
                _countryController.text = val;
              });
            }
          },
        ),
      ],
    );
  }

  Widget _buildFormCard({
    required String stepNum,
    required String title,
    required String subtitle,
    Widget? action,
    required Widget child,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.borderLight),
        boxShadow: AppTheme.shadowSm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LayoutBuilder(
            builder: (context, cardConstraints) {
              final isSmallCard = cardConstraints.maxWidth < 500;
              final headerInfo = Row(
                children: [
                  Container(
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      color: AppTheme.primaryLight,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      stepNum,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        Text(
                          subtitle,
                          style: GoogleFonts.inter(
                            fontSize: 10.5,
                            color: AppTheme.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (!isSmallCard && action != null) ...[
                    const SizedBox(width: 8),
                    action,
                  ],
                ],
              );

              if (isSmallCard && action != null) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [headerInfo, const SizedBox(height: 8), action],
                );
              }
              return headerInfo;
            },
          ),
          const Divider(height: 20),
          child,
        ],
      ),
    );
  }

  // --- Section 01: Company Name Suggestions Dropdown ---
  Widget _buildCompanyNameSuggestionsDropdown() {
    final suggestions = _companyNameSuggestions;
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFE2E8F0), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0x1A0F172A),
            blurRadius: 18,
            offset: Offset(0, 8),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: const Color(0xFFF8FAFC),
            child: Row(
              children: [
                const Icon(
                  Icons.domain,
                  size: 14,
                  color: AppTheme.primary,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'EXISTING COMPANIES IN DIRECTORY (${suggestions.length} MATCHES)',
                    style: GoogleFonts.inter(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 0.5,
                      color: const Color(0xFF64748B),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, thickness: 1, color: Color(0xFFF1F5F9)),

          // Items
          ...suggestions.map((comp) {
            final meta = [
              comp.city?.isNotEmpty == true
                  ? comp.city
                  : (comp.country?.isNotEmpty == true ? comp.country : 'Global'),
              if (comp.contactName?.isNotEmpty == true) comp.contactName,
              if (comp.email.isNotEmpty) comp.email,
            ].whereType<String>().join(' • ');

            final status = comp.status.toUpperCase();
            Color statusBg;
            Color statusFg;
            Color statusBorder;
            if (status == 'ACTIVE') {
              statusBg = const Color(0xFFECFDF5);
              statusFg = const Color(0xFF059669);
              statusBorder = const Color(0xFFA7F3D0);
            } else if (status == 'PENDING') {
              statusBg = const Color(0xFFFFFBEB);
              statusFg = const Color(0xFFD97706);
              statusBorder = const Color(0xFFFDE68A);
            } else {
              statusBg = const Color(0xFFF1F5F9);
              statusFg = const Color(0xFF64748B);
              statusBorder = const Color(0xFFCBD5E1);
            }

            return InkWell(
              onTap: () => _selectCompanyNameSuggestion(comp),
              hoverColor: const Color(0xFFF0FDF4),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: const BoxDecoration(
                  border: Border(
                    bottom: BorderSide(
                      color: Color(0xFFF8FAFC),
                      width: 1,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        color: const Color(0xFFEEF2FF),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      alignment: Alignment.center,
                      child: const Icon(
                        Icons.apartment,
                        size: 16,
                        color: Color(0xFF4F46E5),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  comp.companyName,
                                  style: GoogleFonts.inter(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: const Color(0xFF1E293B),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              const SizedBox(width: 6),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 6,
                                  vertical: 1.5,
                                ),
                                decoration: BoxDecoration(
                                  color: statusBg,
                                  border: Border.all(color: statusBorder),
                                  borderRadius: BorderRadius.circular(9999),
                                ),
                                child: Text(
                                  status,
                                  style: GoogleFonts.inter(
                                    fontSize: 9.5,
                                    fontWeight: FontWeight.w800,
                                    color: statusFg,
                                    letterSpacing: 0.3,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(
                            meta,
                            style: GoogleFonts.inter(
                              fontSize: 11,
                              color: const Color(0xFF64748B),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFECFDF5),
                        border: Border.all(color: const Color(0xFFA7F3D0)),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(
                            Icons.north_west,
                            size: 11,
                            color: Color(0xFF059669),
                          ),
                          const SizedBox(width: 3),
                          Text(
                            'Select',
                            style: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                              color: const Color(0xFF059669),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  // --- Section 01: Duplicate Company Notice Banner ---
  Widget _buildDuplicateCompanyNotice(CompanyResponse existing) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        border: Border.all(color: const Color(0xFFFDE68A), width: 1.5),
        borderRadius: BorderRadius.circular(8),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final isNarrow = constraints.maxWidth < 460;
          final leftContent = Row(
            children: [
              const Icon(
                Icons.warning_amber_rounded,
                size: 18,
                color: Color(0xFFD97706),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text.rich(
                  TextSpan(
                    text: 'Company ',
                    children: [
                      TextSpan(
                        text: '"${existing.companyName}"',
                        style: const TextStyle(fontWeight: FontWeight.w700),
                      ),
                      const TextSpan(
                        text: ' is already registered in directory.',
                      ),
                    ],
                  ),
                  style: GoogleFonts.inter(
                    fontSize: 12.5,
                    color: const Color(0xFF92400E),
                  ),
                ),
              ),
            ],
          );

          final actions = Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // Copy Details
              InkWell(
                onTap: () => _autofillFormWithCompany(existing),
                borderRadius: BorderRadius.circular(6),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4.5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFF59E0B)),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.content_copy,
                        size: 12,
                        color: Color(0xFFB45309),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'Copy Details',
                        style: GoogleFonts.inter(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xFFB45309),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 6),

              // View
              InkWell(
                onTap: () => setState(() => _selectedCompany = existing),
                borderRadius: BorderRadius.circular(6),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 9,
                    vertical: 4.5,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.transparent,
                    border: Border.all(color: const Color(0xFFD97706)),
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(
                        Icons.visibility_outlined,
                        size: 12,
                        color: Color(0xFF92400E),
                      ),
                      const SizedBox(width: 4),
                      Text(
                        'View',
                        style: GoogleFonts.inter(
                          fontSize: 11.5,
                          fontWeight: FontWeight.w600,
                          color: const Color(0xFF92400E),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );

          if (isNarrow) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                leftContent,
                const SizedBox(height: 8),
                actions,
              ],
            );
          }

          return Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Expanded(child: leftContent),
              const SizedBox(width: 10),
              actions,
            ],
          );
        },
      ),
    );
  }

  // --- Website Products Scraped Results Drawer ---
  Widget _buildScrapedProductsDrawer() {
    return Container(
      key: _scrapedDrawerKey,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF8FAFC), Colors.white],
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0E7FF), width: 1.5),
        boxShadow: const [
          BoxShadow(
            color: Color(0x146366F1),
            blurRadius: 18,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Drawer Header
          LayoutBuilder(
            builder: (context, constraints) {
              final isNarrow = constraints.maxWidth < 620;
              final titleGroup = Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF4F46E5), Color(0xFF6366F1)],
                      ),
                      borderRadius: BorderRadius.circular(10),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x334F46E5),
                          blurRadius: 10,
                          offset: Offset(0, 3),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: const Icon(
                      Icons.language,
                      color: Colors.white,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Discovered Products from Website',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Row(
                          children: [
                            Text(
                              'Scanned: ',
                              style: GoogleFonts.inter(
                                fontSize: 11,
                                color: AppTheme.textMuted,
                              ),
                            ),
                            Expanded(
                              child: InkWell(
                                onTap: () async {
                                  final uri = Uri.tryParse(_scrapedWebsiteUrl);
                                  if (uri != null && await canLaunchUrl(uri)) {
                                    await launchUrl(uri);
                                  }
                                },
                                child: Text(
                                  _scrapedWebsiteUrl,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF4F46E5),
                                    decoration: TextDecoration.underline,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        if (_scrapedStrategyUsed.isNotEmpty) ...[
                          const SizedBox(height: 4),
                          Tooltip(
                            message:
                                'Detection Pipeline: $_scrapedStrategyUsed',
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2.5,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFEDE9FE),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(
                                    Icons.bolt,
                                    size: 10.5,
                                    color: Color(0xFF6D28D9),
                                  ),
                                  const SizedBox(width: 4),
                                  Flexible(
                                    child: Text(
                                      _cleanPrimaryStrategy(
                                        _scrapedStrategyUsed,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.inter(
                                        fontSize: 9.5,
                                        fontWeight: FontWeight.w700,
                                        color: const Color(0xFF6D28D9),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              );

              final actions = Row(
                children: [
                  Expanded(
                    child: Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        OutlinedButton.icon(
                          onPressed: _scrapedProducts.isEmpty
                              ? null
                              : _selectAllScrapedProducts,
                          icon: const Icon(Icons.done_all, size: 13),
                          label: Text(
                            'Select All (${_scrapedProducts.length})',
                          ),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 6,
                            ),
                            textStyle: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                            foregroundColor: const Color(0xFF475569),
                            backgroundColor: const Color(0xFFF1F5F9),
                            side: const BorderSide(color: Color(0xFFCBD5E1)),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                        OutlinedButton.icon(
                          onPressed: _selectedScrapedIndices.isEmpty
                              ? null
                              : _deselectAllScrapedProducts,
                          icon: const Icon(
                            Icons.remove_circle_outline,
                            size: 13,
                          ),
                          label: Text(
                            'Clear (${_selectedScrapedIndices.length})',
                          ),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 9,
                              vertical: 6,
                            ),
                            textStyle: GoogleFonts.inter(
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                            foregroundColor: const Color(0xFF475569),
                            backgroundColor: const Color(0xFFF1F5F9),
                            side: const BorderSide(color: Color(0xFFCBD5E1)),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  InkWell(
                    onTap: _closeScrapedDrawer,
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: const Icon(
                        Icons.close,
                        size: 18,
                        color: Color(0xFF94A3B8),
                      ),
                    ),
                  ),
                ],
              );

              if (isNarrow) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [titleGroup, const SizedBox(height: 10), actions],
                );
              }
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(child: titleGroup),
                  const SizedBox(width: 12),
                  actions,
                ],
              );
            },
          ),
          const Divider(height: 24),

          // Drawer Body
          if (_isScrapingWebsite) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 28),
              alignment: Alignment.center,
              child: Column(
                children: [
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: const Color(0xFF6366F1),
                        width: 3,
                      ),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x556366F1),
                          blurRadius: 16,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: Container(
                      width: 12,
                      height: 12,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        color: Color(0xFF4F46E5),
                      ),
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    'Crawling website & discovering product structured data...',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.textPrimary,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Analyzing Schema.org JSON-LD, OpenGraph, and product collections',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      color: AppTheme.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          ] else if (_scrapedProducts.isEmpty) ...[
            Container(
              padding: const EdgeInsets.symmetric(vertical: 24),
              alignment: Alignment.center,
              child: Column(
                children: [
                  const Icon(
                    Icons.search_off_rounded,
                    size: 36,
                    color: Color(0xFFCBD5E1),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'No products could be automatically extracted from this domain.',
                    style: GoogleFonts.inter(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xFF475569),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Please pick products from the master catalog below or register new ones.',
                    style: GoogleFonts.inter(
                      fontSize: 11,
                      color: AppTheme.textMuted,
                    ),
                  ),
                ],
              ),
            ),
          ] else ...[
            // Products Grid
            LayoutBuilder(
              builder: (context, constraints) {
                final crossAxisCount = (constraints.maxWidth / 220)
                    .floor()
                    .clamp(1, 4);
                return ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 380),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const ClampingScrollPhysics(),
                    itemCount: _scrapedProducts.length,
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: crossAxisCount,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      mainAxisExtent: 74,
                    ),
                    itemBuilder: (context, idx) {
                      final item = _scrapedProducts[idx];
                      final isSelected = _selectedScrapedIndices.contains(idx);
                      return InkWell(
                        onTap: () => _toggleScrapedProduct(idx),
                        borderRadius: BorderRadius.circular(10),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 180),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 7,
                          ),
                          decoration: BoxDecoration(
                            color: isSelected
                                ? const Color(0xFFEEF2FF)
                                : Colors.white,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: isSelected
                                  ? const Color(0xFF6366F1)
                                  : const Color(0xFFE2E8F0),
                              width: isSelected ? 1.5 : 1.0,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(
                                  isSelected ? 0.06 : 0.02,
                                ),
                                blurRadius: isSelected ? 8 : 4,
                                offset: const Offset(0, 1),
                              ),
                            ],
                          ),
                          child: Row(
                            children: [
                              SizedBox(
                                width: 20,
                                height: 20,
                                child: Checkbox(
                                  value: isSelected,
                                  activeColor: const Color(0xFF4F46E5),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(4),
                                  ),
                                  onChanged: (_) => _toggleScrapedProduct(idx),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 44,
                                height: 44,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF1F5F9),
                                  borderRadius: BorderRadius.circular(6),
                                  border: Border.all(
                                    color: const Color(0xFFE2E8F0),
                                  ),
                                ),
                                clipBehavior: Clip.antiAlias,
                                child:
                                    (item.imageUrl != null &&
                                        item.imageUrl!.trim().isNotEmpty)
                                    ? Image.network(
                                        item.imageUrl!,
                                        fit: BoxFit.cover,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                const Center(
                                                  child: Icon(
                                                    Icons.inventory_2_outlined,
                                                    size: 20,
                                                    color: Color(0xFF94A3B8),
                                                  ),
                                                ),
                                      )
                                    : const Center(
                                        child: Icon(
                                          Icons.inventory_2_outlined,
                                          size: 20,
                                          color: Color(0xFF94A3B8),
                                        ),
                                      ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      item.name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: GoogleFonts.inter(
                                        fontSize: 12,
                                        fontWeight: FontWeight.w700,
                                        color: AppTheme.textPrimary,
                                      ),
                                    ),
                                    if (item.price != null &&
                                        item.price!.trim().isNotEmpty) ...[
                                      const SizedBox(height: 2),
                                      Text(
                                        item.price!,
                                        maxLines: 1,
                                        style: GoogleFonts.inter(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w800,
                                          color: const Color(0xFF059669),
                                        ),
                                      ),
                                    ],
                                    if (item.matchedCatalogProductId !=
                                        null) ...[
                                      const SizedBox(height: 2),
                                      Container(
                                        padding: const EdgeInsets.symmetric(
                                          horizontal: 5,
                                          vertical: 1.5,
                                        ),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFDBEAFE),
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          children: [
                                            const Icon(
                                              Icons.link,
                                              size: 10,
                                              color: Color(0xFF2563EB),
                                            ),
                                            const SizedBox(width: 3),
                                            Text(
                                              'In Catalog',
                                              style: GoogleFonts.inter(
                                                fontSize: 9.5,
                                                fontWeight: FontWeight.w800,
                                                color: const Color(0xFF2563EB),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                );
              },
            ),
            const SizedBox(height: 12),
            // Drawer Footer
            Container(
              padding: const EdgeInsets.only(top: 10),
              decoration: const BoxDecoration(
                border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
              ),
              child: LayoutBuilder(
                builder: (context, footerConstraints) {
                  final isNarrowFooter = footerConstraints.maxWidth < 520;
                  final countWidget = Text.rich(
                    TextSpan(
                      children: [
                        TextSpan(
                          text: '${_selectedScrapedIndices.length} ',
                          style: GoogleFonts.inter(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF4338CA),
                          ),
                        ),
                        TextSpan(
                          text:
                              'of ${_scrapedProducts.length} website products selected',
                          style: GoogleFonts.inter(
                            fontSize: 11.5,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF4338CA),
                          ),
                        ),
                      ],
                    ),
                  );

                  final hintWidget = Text(
                    'Selected items will be linked with this company upon registration.',
                    style: GoogleFonts.inter(
                      fontSize: 10.5,
                      color: AppTheme.textMuted,
                    ),
                  );

                  if (isNarrowFooter) {
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        countWidget,
                        const SizedBox(height: 4),
                        hintWidget,
                      ],
                    );
                  }

                  return Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      countWidget,
                      const SizedBox(width: 8),
                      Flexible(child: hintWidget),
                    ],
                  );
                },
              ),
            ),
          ],
        ],
      ),
    );
  }

  // --- Live Preview Sidebar ---
  Widget _buildLivePreviewSidebar() {
    final name = _nameController.text.trim().isNotEmpty
        ? _nameController.text.trim()
        : 'Your Company Name';
    final email = _emailController.text.trim().isNotEmpty
        ? _emailController.text.trim()
        : 'contact@company.com';
    final landline = _landlineController.text.trim();
    final city = _cityController.text.trim();
    final country = _countryController.text.trim();
    final website = _websiteController.text.trim();
    final desc = _descriptionController.text.trim();
    final contactName = _contactNameController.text.trim();
    final contactDesignation = _contactDesignationController.text.trim();
    final contactMobile = _contactMobileController.text.trim();
    final contactEmail = _contactEmailController.text.trim();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppTheme.primaryLight,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                children: [
                  const Icon(
                    Icons.visibility,
                    size: 14,
                    color: AppTheme.primary,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    'Live Preview',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.primary,
                    ),
                  ),
                ],
              ),
            ),
            Row(
              children: [
                InkWell(
                  onTap: _shareCurrentPreview,
                  borderRadius: BorderRadius.circular(20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFECFDF5),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: const Color(0xFFA7F3D0)),
                    ),
                    child: Row(
                      children: [
                        const Icon(
                          Icons.share,
                          size: 13,
                          color: Color(0xFF059669),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'Share',
                          style: GoogleFonts.inter(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFF059669),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Real-time card',
                  style: GoogleFonts.inter(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ],
        ),
        const SizedBox(height: 12),

        // Business Card Display
        Container(
          decoration: BoxDecoration(
            gradient: AppTheme.cardGlossGradient,
            borderRadius: BorderRadius.circular(18),
            boxShadow: AppTheme.shadowLg,
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Card Top Header
              Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Avatar Logo
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(
                        color: Colors.white.withValues(alpha: 0.15),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: Colors.white.withValues(alpha: 0.2),
                        ),
                      ),
                      clipBehavior: Clip.antiAlias,
                      child: _selectedFileBytes != null
                          ? Image.memory(_selectedFileBytes!, fit: BoxFit.cover)
                          : (_existingFileUrl != null
                                ? Image.network(
                                    _existingFileUrl!,
                                    fit: BoxFit.cover,
                                    errorBuilder:
                                        (context, error, stackTrace) =>
                                            const Center(
                                              child: Icon(
                                                Icons.apartment,
                                                color: Colors.white70,
                                              ),
                                            ),
                                  )
                                : const Center(
                                    child: Icon(
                                      Icons.apartment,
                                      color: Colors.white70,
                                    ),
                                  )),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            name,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                          if (contactName.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text(
                              '$contactName${contactDesignation.isNotEmpty ? ' â€¢ $contactDesignation' : ''}',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                color: Colors.white.withValues(alpha: 0.75),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                    StatusBadgeChip(status: _status, isMini: true),
                  ],
                ),
              ),

              // Card Details Body
              Container(
                padding: const EdgeInsets.all(18),
                color: Colors.black.withValues(alpha: 0.2),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Key Contact Box (if present)
                    if (contactMobile.isNotEmpty ||
                        contactEmail.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.08),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Key Contact',
                              style: GoogleFonts.inter(
                                fontSize: 10,
                                fontWeight: FontWeight.w700,
                                color: Colors.white54,
                              ),
                            ),
                            const SizedBox(height: 4),
                            if (contactMobile.isNotEmpty)
                              Row(
                                children: [
                                  const Icon(
                                    Icons.phone_iphone,
                                    size: 12,
                                    color: Colors.white70,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    contactMobile,
                                    style: GoogleFonts.inter(
                                      fontSize: 11,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                            if (contactEmail.isNotEmpty)
                              Row(
                                children: [
                                  const Icon(
                                    Icons.email_outlined,
                                    size: 12,
                                    color: Colors.white70,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    contactEmail,
                                    style: GoogleFonts.inter(
                                      fontSize: 11,
                                      color: Colors.white,
                                    ),
                                  ),
                                ],
                              ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                    ],

                    // Corporate email
                    _buildPreviewDetailRow(Icons.email_outlined, email),

                    if (landline.isNotEmpty)
                      _buildPreviewDetailRow(
                        Icons.phone_in_talk_outlined,
                        landline,
                      ),

                    // Location
                    _buildPreviewDetailRow(
                      Icons.location_on_outlined,
                      city.isNotEmpty || country.isNotEmpty
                          ? '${city.isNotEmpty ? '$city, ' : ''}$country'
                          : 'Headquarters Location',
                    ),

                    if (website.isNotEmpty)
                      _buildPreviewDetailRow(
                        Icons.language,
                        website,
                        isAccent: true,
                      ),

                    // Brands Dealt With in Preview
                    if (_selectedBrandIds.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(
                        'Brands Dealt With (${_selectedBrandIds.length}):',
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: _selectedBrandsList.map((b) {
                          return Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                if (b.brandLogo != null &&
                                    b.brandLogo!.isNotEmpty)
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(2),
                                    child: Image.network(
                                      _brandService.getFileUrl(b.brandLogo),
                                      width: 14,
                                      height: 14,
                                      fit: BoxFit.cover,
                                      errorBuilder:
                                          (context, error, stackTrace) =>
                                              const Icon(
                                                Icons.verified,
                                                size: 12,
                                                color: Colors.white,
                                              ),
                                    ),
                                  ),
                                const SizedBox(width: 4),
                                Text(
                                  b.brandName,
                                  style: GoogleFonts.inter(
                                    fontSize: 10,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ],

                    // Products Portfolio in Preview
                    if (_selectedProductIds.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(
                        'Products Portfolio (${_selectedProductIds.length}):',
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Colors.white70,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: _selectedProductsList.map((p) {
                          return Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 8,
                              vertical: 3,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white.withValues(alpha: 0.12),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              '${p.name} (${p.brandName ?? ''})',
                              style: GoogleFonts.inter(
                                fontSize: 10,
                                color: Colors.white,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],

                    if (desc.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Text(
                        desc,
                        style: GoogleFonts.inter(
                          fontSize: 11,
                          color: Colors.white70,
                          height: 1.35,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),

              // Card Footer
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 18,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.4),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      'CORPORATE PROFILE IDENTIFIER',
                      style: GoogleFonts.inter(
                        fontSize: 9,
                        fontWeight: FontWeight.w700,
                        color: Colors.white38,
                        letterSpacing: 0.5,
                      ),
                    ),
                    Row(
                      children: [
                        const Icon(
                          Icons.shield,
                          size: 12,
                          color: Color(0xFF34D399),
                        ),
                        const SizedBox(width: 4),
                        Text(
                          'VERIFIED',
                          style: GoogleFonts.inter(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: const Color(0xFF34D399),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPreviewDetailRow(
    IconData icon,
    String text, {
    bool isAccent = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Icon(icon, size: 13, color: Colors.white60),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: GoogleFonts.inter(
                fontSize: 11,
                color: isAccent ? const Color(0xFF38BDF8) : Colors.white,
                fontWeight: isAccent ? FontWeight.w600 : FontWeight.normal,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  // --- TAB 2: DIRECTORY VIEW ---
  Widget _buildDirectoryView() {
    final companies = _filteredCompanies;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header & Action Bar
          _buildDirectoryHeader(),
          const SizedBox(height: 16),

          if (_isLoadingList) ...[
            const Center(
              child: Padding(
                padding: EdgeInsets.all(40),
                child: CircularProgressIndicator(),
              ),
            ),
          ] else if (companies.isEmpty) ...[
            _buildEmptyState(),
          ] else ...[
            _buildCompaniesGrid(companies),
          ],
        ],
      ),
    );
  }

  Widget _buildDirectoryHeader() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.borderLight),
        boxShadow: AppTheme.shadowSm,
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Registered Companies Directory',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.textPrimary,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'Manage, view, edit, and delete company records in the system.',
                style: GoogleFonts.inter(
                  fontSize: 11,
                  color: AppTheme.textSecondary,
                ),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: CompanySearchBar(
                      allCompanies: _companies,
                      searchQuery: _searchQuery,
                      onSearchChanged: (val) =>
                          setState(() => _searchQuery = val),
                      onCompanyInspect: (comp) =>
                          setState(() => _selectedCompany = comp),
                      onCompanySelected: (comp) =>
                          setState(() => _searchQuery = comp.companyName),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: _fetchCompanies,
                    icon: const Icon(Icons.refresh, size: 20),
                    tooltip: 'Refresh Database',
                    style: IconButton.styleFrom(
                      backgroundColor: AppTheme.bgSubtle,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  // Excel Export Button
                  ElevatedButton.icon(
                    onPressed: _isExportingExcel || _companies.isEmpty
                        ? null
                        : _exportToExcel,
                    icon: _isExportingExcel
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.file_download, size: 15),
                    label: Text(
                      _isExportingExcel ? 'Exporting...' : 'Export Excel',
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF059669),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      textStyle: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  // PDF Export Button
                  ElevatedButton.icon(
                    onPressed: _isExportingPdf || _companies.isEmpty
                        ? null
                        : _exportToPdf,
                    icon: _isExportingPdf
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Colors.white,
                            ),
                          )
                        : const Icon(Icons.picture_as_pdf, size: 15),
                    label: Text(
                      _isExportingPdf ? 'Generating...' : 'Export PDF',
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFE11D48),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      textStyle: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _switchToRegister,
                    icon: const Icon(Icons.add, size: 15),
                    label: const Text('New Company'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppTheme.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 8,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      textStyle: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 40),
        child: Column(
          children: [
            Container(
              width: 64,
              height: 64,
              decoration: BoxDecoration(
                color: AppTheme.primaryLight,
                shape: BoxShape.circle,
              ),
              child: const Icon(
                Icons.apartment,
                size: 32,
                color: AppTheme.primary,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'No Companies Found',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppTheme.textPrimary,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'No records match your criteria or none have been registered yet.',
              style: GoogleFonts.inter(
                fontSize: 13,
                color: AppTheme.textSecondary,
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _switchToRegister,
              icon: const Icon(Icons.add, size: 16),
              label: const Text('Register New Company'),
              style: ElevatedButton.styleFrom(
                backgroundColor: AppTheme.primary,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 12,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompaniesGrid(List<CompanyResponse> companies) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth > 1100
            ? 3
            : (constraints.maxWidth > 650 ? 2 : 1);

        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: crossAxisCount,
            crossAxisSpacing: 16,
            mainAxisSpacing: 16,
            mainAxisExtent: 360,
          ),
          itemCount: companies.length,
          itemBuilder: (context, index) {
            final comp = companies[index];
            return _buildCompanyCard(comp);
          },
        );
      },
    );
  }

  Widget _buildCompanyCard(CompanyResponse comp) {
    return InkWell(
      onTap: () => setState(() => _selectedCompany = comp),
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: AppTheme.bgSurface,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppTheme.borderLight),
          boxShadow: AppTheme.shadowSm,
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Card Header
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 8),
              child: Row(
                children: [
                  Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        decoration: BoxDecoration(
                          color: AppTheme.primaryLight,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        clipBehavior: Clip.antiAlias,
                        child:
                            comp.allCards.isNotEmpty &&
                                !comp.allCards.first.toLowerCase().endsWith(
                                  '.pdf',
                                )
                            ? Image.network(
                                _companyService.getFileUrl(comp.allCards.first),
                                fit: BoxFit.cover,
                                errorBuilder: (context, error, stackTrace) =>
                                    Center(
                                      child: Text(
                                        comp.companyName.isNotEmpty
                                            ? comp.companyName
                                                  .substring(0, 1)
                                                  .toUpperCase()
                                            : 'C',
                                        style: GoogleFonts.plusJakartaSans(
                                          fontWeight: FontWeight.w800,
                                          color: AppTheme.primary,
                                          fontSize: 16,
                                        ),
                                      ),
                                    ),
                              )
                            : Center(
                                child: Text(
                                  comp.companyName.isNotEmpty
                                      ? comp.companyName
                                            .substring(0, 1)
                                            .toUpperCase()
                                      : 'C',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.primary,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                      ),
                      if (comp.allCards.length > 1)
                        Positioned(
                          right: -3,
                          bottom: -3,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 4,
                              vertical: 1,
                            ),
                            decoration: BoxDecoration(
                              color: AppTheme.primary,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                color: Colors.white,
                                width: 1.5,
                              ),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(
                                  Icons.collections_rounded,
                                  size: 8,
                                  color: Colors.white,
                                ),
                                const SizedBox(width: 2),
                                Text(
                                  '${comp.allCards.length}',
                                  style: GoogleFonts.inter(
                                    fontSize: 8,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          comp.companyName,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            fontWeight: FontWeight.w700,
                            color: AppTheme.textPrimary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (comp.contactName != null &&
                            comp.contactName!.isNotEmpty) ...[
                          const SizedBox(height: 1),
                          Row(
                            children: [
                              const Icon(
                                Icons.person_outline,
                                size: 12,
                                color: Color(0xFF2563EB),
                              ),
                              const SizedBox(width: 3),
                              Expanded(
                                child: Text(
                                  comp.contactName!,
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    fontWeight: FontWeight.w600,
                                    color: const Color(0xFF2563EB),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 6,
                      vertical: 3,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF1F5F9),
                      borderRadius: BorderRadius.circular(5),
                      border: Border.all(color: const Color(0xFFCBD5E1)),
                    ),
                    child: Text(
                      '#${comp.id}',
                      style: GoogleFonts.inter(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: const Color(0xFF64748B),
                      ),
                    ),
                  ),
                  const SizedBox(width: 6),
                  StatusBadgeChip(status: comp.status, isMini: true),
                ],
              ),
            ),

            // Description & Details
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      comp.description != null && comp.description!.isNotEmpty
                          ? comp.description!
                          : 'No corporate summary provided.',
                      style: GoogleFonts.inter(
                        fontSize: 11,
                        color: AppTheme.textSecondary,
                        height: 1.35,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),

                    // Contact Details Box
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFF1F5F9)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.mail_outline,
                                size: 12,
                                color: Color(0xFF64748B),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  comp.email.isNotEmpty ? comp.email : 'N/A',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    color: const Color(0xFF475569),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          if (comp.landline != null &&
                              comp.landline!.isNotEmpty) ...[
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                const Icon(
                                  Icons.phone_outlined,
                                  size: 12,
                                  color: Color(0xFF64748B),
                                ),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: Text(
                                    comp.landline!,
                                    style: GoogleFonts.inter(
                                      fontSize: 11,
                                      color: const Color(0xFF475569),
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              const Icon(
                                Icons.location_on_outlined,
                                size: 12,
                                color: Color(0xFF64748B),
                              ),
                              const SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  [comp.city, comp.country]
                                          .where(
                                            (p) => p != null && p.isNotEmpty,
                                          )
                                          .join(', ')
                                          .isNotEmpty
                                      ? [comp.city, comp.country]
                                            .where(
                                              (p) => p != null && p.isNotEmpty,
                                            )
                                            .join(', ')
                                      : 'Global',
                                  style: GoogleFonts.inter(
                                    fontSize: 11,
                                    color: const Color(0xFF475569),
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Brands row
                    if (comp.brands.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.military_tech_outlined,
                            size: 12,
                            color: Color(0xFF4F46E5),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Brands (${comp.brands.length}):',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textMuted,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: comp.brands.map((b) {
                                  return Container(
                                    margin: const EdgeInsets.only(right: 4),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 7,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFF1F5F9),
                                      borderRadius: BorderRadius.circular(20),
                                      border: Border.all(
                                        color: const Color(0xFFE2E8F0),
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        if (b.brandLogo != null &&
                                            b.brandLogo!.isNotEmpty)
                                          Container(
                                            width: 12,
                                            height: 12,
                                            margin: const EdgeInsets.only(
                                              right: 4,
                                            ),
                                            child: Image.network(
                                              _brandService.getFileUrl(
                                                b.brandLogo,
                                              ),
                                              fit: BoxFit.contain,
                                              errorBuilder:
                                                  (
                                                    context,
                                                    error,
                                                    stackTrace,
                                                  ) => Container(
                                                    width: 6,
                                                    height: 6,
                                                    decoration:
                                                        const BoxDecoration(
                                                          color: Color(
                                                            0xFFEA580C,
                                                          ),
                                                          shape:
                                                              BoxShape.circle,
                                                        ),
                                                  ),
                                            ),
                                          )
                                        else
                                          Container(
                                            width: 6,
                                            height: 6,
                                            margin: const EdgeInsets.only(
                                              right: 4,
                                            ),
                                            decoration: const BoxDecoration(
                                              color: Color(0xFFEA580C),
                                              shape: BoxShape.circle,
                                            ),
                                          ),
                                        Text(
                                          b.brandName,
                                          style: GoogleFonts.inter(
                                            fontSize: 10,
                                            fontWeight: FontWeight.w600,
                                            color: const Color(0xFF334155),
                                          ),
                                        ),
                                      ],
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],

                    // Products row
                    if (comp.products.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.inventory_2_outlined,
                            size: 12,
                            color: Color(0xFF4F46E5),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Products (${comp.products.length}):',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textMuted,
                            ),
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Row(
                                children: comp.products.map((p) {
                                  return Container(
                                    margin: const EdgeInsets.only(right: 4),
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: const Color(0xFFECFDF5),
                                      borderRadius: BorderRadius.circular(4),
                                      border: Border.all(
                                        color: const Color(0xFFA7F3D0),
                                      ),
                                    ),
                                    child: Text(
                                      p.name,
                                      style: GoogleFonts.inter(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w600,
                                        color: const Color(0xFF065F46),
                                      ),
                                    ),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ],
                ),
              ),
            ),

            // Actions Footer (Fixed, zero-shift static layout)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              decoration: const BoxDecoration(
                color: Color(0xFFF8FAFC),
                border: Border(top: BorderSide(color: Color(0xFFE2E8F0))),
              ),
              child: Row(
                children: [
                  // View Button
                  Expanded(
                    flex: 10,
                    child: _buildCardActionButton(
                      label: 'View',
                      icon: Icons.visibility_outlined,
                      bgColor: const Color(0xFFF1F5F9),
                      borderColor: const Color(0xFFCBD5E1),
                      textColor: const Color(0xFF334155),
                      onTap: () => setState(() => _selectedCompany = comp),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // Share Button
                  Expanded(
                    flex: 11,
                    child: _buildCardActionButton(
                      label: 'Share',
                      icon: Icons.share_rounded,
                      bgColor: const Color(0xFFECFDF5),
                      borderColor: const Color(0xFFA7F3D0),
                      textColor: const Color(0xFF059669),
                      onTap: () => CompanyShareDialog.show(context, comp),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // PDF Button
                  Expanded(
                    flex: 9,
                    child: _buildCardActionButton(
                      label: 'PDF',
                      icon: Icons.picture_as_pdf_rounded,
                      bgColor: const Color(0xFFFEF2F2),
                      borderColor: const Color(0xFFFECACA),
                      textColor: const Color(0xFFDC2626),
                      onTap: () => _downloadCompanyPdf(comp),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // Edit Button
                  Expanded(
                    flex: 9,
                    child: _buildCardActionButton(
                      label: 'Edit',
                      icon: Icons.edit_outlined,
                      bgColor: const Color(0xFFEFF6FF),
                      borderColor: const Color(0xFFBFDBFE),
                      textColor: const Color(0xFF2563EB),
                      onTap: () => _startEdit(comp),
                    ),
                  ),
                  const SizedBox(width: 4),

                  // Delete Button
                  InkWell(
                    onTap: () => _promptDelete(comp),
                    borderRadius: BorderRadius.circular(6),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFEF2F2),
                        borderRadius: BorderRadius.circular(6),
                        border: Border.all(color: const Color(0xFFFECACA)),
                      ),
                      child: const Icon(
                        Icons.delete_outline_rounded,
                        size: 14,
                        color: Color(0xFFDC2626),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCardActionButton({
    required String label,
    required IconData icon,
    required Color bgColor,
    required Color borderColor,
    required Color textColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(6),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: borderColor),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(icon, size: 12, color: textColor),
            const SizedBox(width: 3),
            Flexible(
              child: Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 10.5,
                  fontWeight: FontWeight.w700,
                  color: textColor,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- View Detail Modal Dialog ---
  Widget _buildCompanyDetailModal(CompanyResponse comp) {
    final screenHeight = MediaQuery.of(context).size.height;
    return Container(
      color: Colors.black54,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
      child: Material(
        color: Colors.transparent,
        child: Container(
          constraints: BoxConstraints(
            maxWidth: 500,
            maxHeight: screenHeight * 0.88,
          ),
          decoration: BoxDecoration(
            color: AppTheme.bgSurface,
            borderRadius: BorderRadius.circular(16),
            boxShadow: AppTheme.shadowLg,
            border: Border.all(color: AppTheme.borderLight),
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // FIXED Header
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: const BoxDecoration(
                  color: AppTheme.bgSubtle,
                  border: Border(
                    bottom: BorderSide(color: AppTheme.borderLight),
                  ),
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Enterprise Profile • ID #${comp.id}',
                            style: GoogleFonts.inter(
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.textMuted,
                              letterSpacing: 0.2,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            comp.companyName,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 15,
                              fontWeight: FontWeight.w700,
                              color: AppTheme.textPrimary,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    StatusBadgeChip(status: comp.status, isMini: true),
                    const SizedBox(width: 4),
                    IconButton(
                      onPressed: () => setState(() => _selectedCompany = null),
                      icon: const Icon(
                        Icons.close,
                        size: 18,
                        color: AppTheme.textSecondary,
                      ),
                      visualDensity: VisualDensity.compact,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(
                        minWidth: 28,
                        minHeight: 28,
                      ),
                    ),
                  ],
                ),
              ),

              // SCROLLABLE Body (Header & Footer stay permanently fixed)
              Flexible(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(12),
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Meta Bar (Structured grid)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSubtle,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppTheme.borderLight),
                        ),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: _buildModalMetaItem(
                                    'Corporate Email',
                                    comp.email,
                                    icon: Icons.mail_outline,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _buildModalMetaItem(
                                    'Landline',
                                    comp.landline?.isNotEmpty == true
                                        ? comp.landline!
                                        : 'Not Specified',
                                    icon: Icons.phone_outlined,
                                  ),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(vertical: 6),
                              child: Divider(
                                height: 1,
                                thickness: 1,
                                color: AppTheme.borderLight.withValues(
                                  alpha: 0.6,
                                ),
                              ),
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(
                                  child: _buildModalMetaItem(
                                    'Contact Person',
                                    '${comp.contactName ?? 'N/A'}${comp.contactDesignation != null && comp.contactDesignation!.isNotEmpty ? ' (${comp.contactDesignation})' : ''}',
                                    icon: Icons.person_outline,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: _buildModalMetaItem(
                                    'Contact Mobile',
                                    comp.contactMobileNumber?.isNotEmpty == true
                                        ? comp.contactMobileNumber!
                                        : 'N/A',
                                    icon: Icons.smartphone_outlined,
                                  ),
                                ),
                              ],
                            ),
                            if (comp.contactEmail != null &&
                                comp.contactEmail!.trim().isNotEmpty &&
                                comp.contactEmail != comp.email) ...[
                              Padding(
                                padding: const EdgeInsets.symmetric(
                                  vertical: 6,
                                ),
                                child: Divider(
                                  height: 1,
                                  thickness: 1,
                                  color: AppTheme.borderLight.withValues(
                                    alpha: 0.6,
                                  ),
                                ),
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _buildModalMetaItem(
                                      'Contact Direct Email',
                                      comp.contactEmail!,
                                      icon: Icons.alternate_email_rounded,
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ],
                        ),
                      ),
                      const SizedBox(height: 8),

                      // Registered Address Card
                      Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppTheme.bgSurface,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppTheme.borderLight),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.all(5),
                              decoration: BoxDecoration(
                                color: AppTheme.primaryLight,
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Icon(
                                Icons.location_on_outlined,
                                size: 13,
                                color: AppTheme.primary,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'REGISTERED ADDRESS',
                                    style: GoogleFonts.inter(
                                      fontSize: 9,
                                      fontWeight: FontWeight.w700,
                                      color: AppTheme.textMuted,
                                      letterSpacing: 0.5,
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    comp.address ?? 'Not Specified',
                                    style: GoogleFonts.inter(
                                      fontSize: 11.5,
                                      fontWeight: FontWeight.w600,
                                      color: AppTheme.textPrimary,
                                    ),
                                  ),
                                  if ((comp.city != null &&
                                          comp.city!.isNotEmpty) ||
                                      (comp.country != null &&
                                          comp.country!.isNotEmpty)) ...[
                                    const SizedBox(height: 1),
                                    Text(
                                      [comp.city, comp.country]
                                          .where(
                                            (s) => s != null && s.isNotEmpty,
                                          )
                                          .join(', '),
                                      style: GoogleFonts.inter(
                                        fontSize: 10.5,
                                        color: AppTheme.textSecondary,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      // Online Presence / Website Card
                      if (comp.website != null &&
                          comp.website!.trim().isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: const Color(0xFFEFF6FF),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFFBFDBFE)),
                          ),
                          child: Row(
                            children: [
                              Container(
                                padding: const EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  color: const Color(0xFFDBEAFE),
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: const Icon(
                                  Icons.language_outlined,
                                  size: 13,
                                  color: Color(0xFF2563EB),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'ONLINE PRESENCE',
                                      style: GoogleFonts.inter(
                                        fontSize: 9,
                                        fontWeight: FontWeight.w700,
                                        color: const Color(0xFF1E40AF),
                                        letterSpacing: 0.5,
                                      ),
                                    ),
                                    const SizedBox(height: 2),
                                    InkWell(
                                      onTap: () async {
                                        final uri = Uri.tryParse(comp.website!);
                                        if (uri != null) launchUrl(uri);
                                      },
                                      child: Text(
                                        comp.website!,
                                        style: GoogleFonts.inter(
                                          fontSize: 11,
                                          fontWeight: FontWeight.w600,
                                          color: const Color(0xFF2563EB),
                                          decoration: TextDecoration.underline,
                                        ),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const Icon(
                                Icons.open_in_new,
                                size: 13,
                                color: Color(0xFF3B82F6),
                              ),
                            ],
                          ),
                        ),
                      ],
                      const SizedBox(height: 8),

                      // Brands Dealt With Section (Rich Cards matching Angular)
                      if (comp.brands.isNotEmpty) ...[
                        Row(
                          children: [
                            const Icon(
                              Icons.military_tech_rounded,
                              size: 14,
                              color: AppTheme.primary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Brands Dealt With (${comp.brands.length})',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: comp.brands.length,
                          separatorBuilder: (context, index) =>
                              const SizedBox(height: 5),
                          itemBuilder: (context, index) =>
                              _buildModalBrandCard(comp.brands[index]),
                        ),
                        const SizedBox(height: 10),
                      ],

                      // Products Portfolio Section (Rich Cards matching Angular)
                      if (comp.products.isNotEmpty) ...[
                        Row(
                          children: [
                            const Icon(
                              Icons.inventory_2_rounded,
                              size: 14,
                              color: Color(0xFF6B21A8),
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Products Portfolio (${comp.products.length})',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: comp.products.length,
                          separatorBuilder: (context, index) =>
                              const SizedBox(height: 5),
                          itemBuilder: (context, index) =>
                              _buildModalProductCard(comp.products[index]),
                        ),
                        const SizedBox(height: 10),
                      ],

                      // Description Section
                      if (comp.description != null &&
                          comp.description!.trim().isNotEmpty) ...[
                        Row(
                          children: [
                            const Icon(
                              Icons.notes_rounded,
                              size: 14,
                              color: AppTheme.textSecondary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Description',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 4),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: AppTheme.bgSubtle,
                            borderRadius: BorderRadius.circular(7),
                            border: Border.all(color: AppTheme.borderLight),
                          ),
                          child: Text(
                            comp.description!,
                            style: GoogleFonts.inter(
                              fontSize: 11,
                              color: AppTheme.textSecondary,
                              height: 1.35,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),
                      ],

                      // Visiting Cards & Brand Documents (Multi-Card Support matching Angular)
                      if (comp.allCards.isNotEmpty) ...[
                        Row(
                          children: [
                            const Icon(
                              Icons.collections_rounded,
                              size: 14,
                              color: AppTheme.primary,
                            ),
                            const SizedBox(width: 4),
                            Text(
                              'Visiting Cards & Brand Documents (${comp.allCards.length})',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w700,
                                color: AppTheme.textPrimary,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 6),
                        ListView.separated(
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          itemCount: comp.allCards.length,
                          separatorBuilder: (context, index) =>
                              const SizedBox(height: 6),
                          itemBuilder: (context, idx) {
                            final card = comp.allCards[idx];
                            final isPdf = card.toLowerCase().endsWith('.pdf');
                            if (isPdf) {
                              return InkWell(
                                onTap: () {
                                  final url = _companyService.getFileUrl(card);
                                  final uri = Uri.tryParse(url);
                                  if (uri != null) launchUrl(uri);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFEF2F2),
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: const Color(0xFFFECACA),
                                    ),
                                  ),
                                  child: Row(
                                    children: [
                                      Container(
                                        padding: const EdgeInsets.all(6),
                                        decoration: BoxDecoration(
                                          color: const Color(0xFFFEE2E2),
                                          borderRadius: BorderRadius.circular(
                                            6,
                                          ),
                                        ),
                                        child: const Icon(
                                          Icons.picture_as_pdf,
                                          color: AppTheme.error,
                                          size: 16,
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Column(
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Text(
                                              'Visiting Card (PDF)',
                                              style: GoogleFonts.inter(
                                                fontSize: 11,
                                                fontWeight: FontWeight.w700,
                                                color: AppTheme.error,
                                              ),
                                            ),
                                            Text(
                                              'Open document ›',
                                              style: GoogleFonts.inter(
                                                fontSize: 9.5,
                                                color: const Color(0xFF991B1B),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      const Icon(
                                        Icons.open_in_new,
                                        size: 13,
                                        color: AppTheme.error,
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            } else {
                              return InkWell(
                                onTap: () {
                                  final url = _companyService.getFileUrl(card);
                                  final uri = Uri.tryParse(url);
                                  if (uri != null) launchUrl(uri);
                                },
                                borderRadius: BorderRadius.circular(8),
                                child: Container(
                                  height: 135,
                                  width: double.infinity,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    border: Border.all(
                                      color: AppTheme.borderLight,
                                    ),
                                    color: AppTheme.bgSubtle,
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: Stack(
                                    fit: StackFit.expand,
                                    children: [
                                      Image.network(
                                        _companyService.getFileUrl(card),
                                        fit: BoxFit.contain,
                                        errorBuilder:
                                            (context, error, stackTrace) =>
                                                const Center(
                                                  child: Icon(
                                                    Icons.broken_image,
                                                    size: 32,
                                                    color: AppTheme.textMuted,
                                                  ),
                                                ),
                                      ),
                                      Positioned(
                                        right: 6,
                                        bottom: 6,
                                        child: Container(
                                          padding: const EdgeInsets.all(4),
                                          decoration: BoxDecoration(
                                            color: Colors.black.withValues(
                                              alpha: 0.6,
                                            ),
                                            borderRadius: BorderRadius.circular(
                                              4,
                                            ),
                                          ),
                                          child: const Icon(
                                            Icons.fullscreen_rounded,
                                            size: 14,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            }
                          },
                        ),
                      ],
                    ],
                  ),
                ),
              ),

              // FIXED Footer Actions
              Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 10,
                ),
                decoration: const BoxDecoration(
                  color: AppTheme.bgSubtle,
                  border: Border(top: BorderSide(color: AppTheme.borderLight)),
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Primary Actions Row: Share Contact & PDF Profile
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () =>
                                CompanyShareDialog.show(context, comp),
                            icon: const Icon(Icons.share_rounded, size: 15),
                            label: Text(
                              'Share Contact',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF059669),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => _downloadCompanyPdf(comp),
                            icon: const Icon(
                              Icons.picture_as_pdf_rounded,
                              size: 15,
                            ),
                            label: Text(
                              'PDF Profile',
                              style: GoogleFonts.inter(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFFDC2626),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(vertical: 9),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),

                    // Secondary Actions Row: Delete, Edit, Close
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton.icon(
                            onPressed: () {
                              final target = comp;
                              setState(() => _selectedCompany = null);
                              _promptDelete(target);
                            },
                            icon: const Icon(
                              Icons.delete_outline_rounded,
                              size: 15,
                              color: AppTheme.error,
                            ),
                            label: Text(
                              'Delete',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                color: AppTheme.error,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: OutlinedButton.styleFrom(
                              backgroundColor: const Color(0xFFFEF2F2),
                              side: const BorderSide(color: Color(0xFFFECACA)),
                              padding: const EdgeInsets.symmetric(
                                vertical: 8.5,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: () => _startEdit(comp),
                            icon: const Icon(Icons.edit_rounded, size: 14),
                            label: Text(
                              'Edit',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppTheme.primary,
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(
                                vertical: 8.5,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () =>
                                setState(() => _selectedCompany = null),
                            style: OutlinedButton.styleFrom(
                              side: const BorderSide(
                                color: AppTheme.borderLight,
                              ),
                              backgroundColor: AppTheme.bgSurface,
                              padding: const EdgeInsets.symmetric(
                                vertical: 8.5,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            child: Text(
                              'Close',
                              style: GoogleFonts.inter(
                                fontSize: 11.5,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.textSecondary,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildModalMetaItem(String label, String value, {IconData? icon}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            if (icon != null) ...[
              Icon(icon, size: 10, color: AppTheme.textMuted),
              const SizedBox(width: 3),
            ],
            Expanded(
              child: Text(
                label,
                style: GoogleFonts.inter(
                  fontSize: 9,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.textMuted,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 11,
            fontWeight: FontWeight.w600,
            color: AppTheme.textPrimary,
          ),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  Widget _buildModalBrandCard(BrandResponse brand) {
    final bool isFeatured = brand.isFeatured;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.borderLight),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: AppTheme.bgSubtle,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppTheme.borderLight),
            ),
            clipBehavior: Clip.antiAlias,
            child: brand.brandLogo != null && brand.brandLogo!.isNotEmpty
                ? Image.network(
                    _brandService.getFileUrl(brand.brandLogo),
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => Center(
                      child: Text(
                        brand.brandName.length >= 2
                            ? brand.brandName.substring(0, 2).toUpperCase()
                            : brand.brandName.toUpperCase(),
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: AppTheme.primary,
                        ),
                      ),
                    ),
                  )
                : Center(
                    child: Text(
                      brand.brandName.length >= 2
                          ? brand.brandName.substring(0, 2).toUpperCase()
                          : brand.brandName.toUpperCase(),
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        fontWeight: FontWeight.w800,
                        color: AppTheme.primary,
                      ),
                    ),
                  ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  brand.brandName,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (isFeatured) ...[
                  const SizedBox(height: 2),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 5,
                      vertical: 1.5,
                    ),
                    decoration: BoxDecoration(
                      color: const Color(0xFFFEF3C7),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(color: const Color(0xFFFDE68A)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(
                          Icons.star_rounded,
                          size: 10,
                          color: Color(0xFFD97706),
                        ),
                        const SizedBox(width: 2),
                        Text(
                          'Featured Brand',
                          style: GoogleFonts.inter(
                            fontSize: 9.5,
                            fontWeight: FontWeight.w700,
                            color: const Color(0xFFB45309),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModalProductCard(ProductResponse prod) {
    final bool isFeatured = prod.isFeatured;
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: AppTheme.bgSurface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.borderLight),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: AppTheme.bgSubtle,
              borderRadius: BorderRadius.circular(6),
              border: Border.all(color: AppTheme.borderLight),
            ),
            clipBehavior: Clip.antiAlias,
            child: prod.image != null && prod.image!.isNotEmpty
                ? Image.network(
                    _productService.getFileUrl(prod.image),
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => const Center(
                      child: Icon(
                        Icons.inventory_2_outlined,
                        size: 18,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  )
                : const Center(
                    child: Icon(
                      Icons.inventory_2_outlined,
                      size: 18,
                      color: AppTheme.textMuted,
                    ),
                  ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    if (prod.brandName != null &&
                        prod.brandName!.isNotEmpty) ...[
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: AppTheme.primaryLight.withValues(alpha: 0.6),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.military_tech_outlined,
                              size: 10,
                              color: AppTheme.primary,
                            ),
                            const SizedBox(width: 2),
                            Text(
                              prod.brandName!,
                              style: GoogleFonts.inter(
                                fontSize: 9.5,
                                fontWeight: FontWeight.w600,
                                color: AppTheme.primary,
                              ),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 4),
                    ],
                    if (isFeatured)
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 5,
                          vertical: 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFEF3C7),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: const Color(0xFFFDE68A)),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(
                              Icons.star_rounded,
                              size: 9,
                              color: Color(0xFFD97706),
                            ),
                            const SizedBox(width: 1),
                            Text(
                              'Featured',
                              style: GoogleFonts.inter(
                                fontSize: 9,
                                fontWeight: FontWeight.w700,
                                color: const Color(0xFFB45309),
                              ),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  prod.name,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: AppTheme.textPrimary,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if ((prod.categoryName != null &&
                        prod.categoryName!.isNotEmpty) ||
                    (prod.subCategoryName != null &&
                        prod.subCategoryName!.isNotEmpty)) ...[
                  const SizedBox(height: 1),
                  Text(
                    [
                      prod.categoryName,
                      prod.subCategoryName,
                    ].where((s) => s != null && s.isNotEmpty).join(' › '),
                    style: GoogleFonts.inter(
                      fontSize: 10,
                      color: AppTheme.textMuted,
                      fontWeight: FontWeight.w500,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

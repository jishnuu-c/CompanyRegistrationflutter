import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../models/brand_model.dart';
import 'api_config.dart';
import 'auth_service.dart';

class BrandService {
  final ApiConfig _config = ApiConfig();
  final AuthService _auth = AuthService();

  String get _apiUrl => '${_config.apiUrl}/brands';

  Future<List<BrandResponse>> getAllBrands() async {
    final response = await http
        .get(
          Uri.parse('$_apiUrl/get-all'),
          headers: _auth.getAuthHeaders({'Accept': 'application/json'}),
        )
        .timeout(const Duration(seconds: 10));

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final dynamic decoded = jsonDecode(utf8.decode(response.bodyBytes));
      if (decoded is List) {
        return decoded
            .map((e) => BrandResponse.fromJson(e as Map<String, dynamic>))
            .toList();
      }
      return [];
    } else {
      throw Exception('Failed to load brands (status: ${response.statusCode})');
    }
  }

  Future<BrandResponse> getBrandById(int id) async {
    final response = await http
        .get(
          Uri.parse('$_apiUrl/$id'),
          headers: _auth.getAuthHeaders({'Accept': 'application/json'}),
        )
        .timeout(const Duration(seconds: 10));

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final dynamic decoded = jsonDecode(utf8.decode(response.bodyBytes));
      return BrandResponse.fromJson(decoded as Map<String, dynamic>);
    } else {
      throw Exception(
        'Failed to load brand #$id (status: ${response.statusCode})',
      );
    }
  }

  Future<BrandResponse> createBrand(
    BrandRequest brandData, {
    Uint8List? fileBytes,
    String? fileName,
    String? filePath,
  }) async {
    final uri = Uri.parse('$_apiUrl/create');
    final request = http.MultipartRequest('POST', uri);
    request.headers.addAll(
      _auth.getAuthHeaders({'Accept': 'application/json'}),
    );

    // JSON DTO part (send as both 'brandRequestDto' and 'data' for backend compatibility)
    final jsonStr = jsonEncode(brandData.toJson());
    request.files.add(
      http.MultipartFile.fromString(
        'brandRequestDto',
        jsonStr,
        contentType: http.MediaType('application', 'json'),
      ),
    );
    request.files.add(
      http.MultipartFile.fromString(
        'data',
        jsonStr,
        contentType: http.MediaType('application', 'json'),
      ),
    );

    // File part
    if (fileBytes != null) {
      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          fileBytes,
          filename: fileName ?? 'brand_logo.png',
        ),
      );
    } else if (filePath != null && !kIsWeb) {
      request.files.add(
        await http.MultipartFile.fromPath('file', filePath, filename: fileName),
      );
    }

    final streamed = await request.send().timeout(const Duration(seconds: 15));
    final response = await http.Response.fromStream(streamed);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final dynamic decoded = jsonDecode(utf8.decode(response.bodyBytes));
      return BrandResponse.fromJson(decoded as Map<String, dynamic>);
    } else {
      final body = response.body;
      throw Exception('Failed to create brand: $body');
    }
  }

  Future<BrandResponse> updateBrand(
    int id,
    BrandRequest brandData, {
    Uint8List? fileBytes,
    String? fileName,
    String? filePath,
  }) async {
    final uri = Uri.parse('$_apiUrl/update/$id');
    final request = http.MultipartRequest('PUT', uri);
    request.headers.addAll(
      _auth.getAuthHeaders({'Accept': 'application/json'}),
    );

    final jsonStr = jsonEncode(brandData.toJson());
    request.files.add(
      http.MultipartFile.fromString(
        'brandRequestDto',
        jsonStr,
        contentType: http.MediaType('application', 'json'),
      ),
    );
    request.files.add(
      http.MultipartFile.fromString(
        'data',
        jsonStr,
        contentType: http.MediaType('application', 'json'),
      ),
    );

    if (fileBytes != null) {
      request.files.add(
        http.MultipartFile.fromBytes(
          'file',
          fileBytes,
          filename: fileName ?? 'brand_logo.png',
        ),
      );
    } else if (filePath != null && !kIsWeb) {
      request.files.add(
        await http.MultipartFile.fromPath('file', filePath, filename: fileName),
      );
    }

    final streamed = await request.send().timeout(const Duration(seconds: 15));
    final response = await http.Response.fromStream(streamed);

    if (response.statusCode >= 200 && response.statusCode < 300) {
      final dynamic decoded = jsonDecode(utf8.decode(response.bodyBytes));
      return BrandResponse.fromJson(decoded as Map<String, dynamic>);
    } else {
      final body = response.body;
      throw Exception('Failed to update brand: $body');
    }
  }

  Future<void> deleteBrand(int id) async {
    final response = await http
        .delete(
          Uri.parse('$_apiUrl/delete/$id'),
          headers: _auth.getAuthHeaders({'Accept': 'application/json'}),
        )
        .timeout(const Duration(seconds: 10));

    if (response.statusCode >= 200 && response.statusCode < 300) {
      return;
    } else {
      throw Exception('Failed to delete brand #$id');
    }
  }

  String getFileUrl(String? path) {
    return _config.getFileUrl(path);
  }
}
